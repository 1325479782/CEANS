#!/bin/sh

python -u -c 'import torch; print(torch.__version__)'

CODE_PATH=codes # Assuming your Python script is in 'codes/run.py'
DATA_PATH=data
SAVE_PATH=models

MODE=train
MODEL=TransE
DATASET=FB15k-237
GPU_DEVICE=0
SAVE_ID=14 # An identifier for this specific run/configuration

FULL_DATA_PATH=$DATA_PATH/$DATASET
SAVE=$SAVE_PATH/"$MODEL"_"$DATASET"_"$SAVE_ID"

# Best Configs / Training Parameters
BATCH_SIZE=1024
NEGATIVE_SAMPLE_SIZE=64
HIDDEN_DIM=1000
GAMMA=9.0
ALPHA=1.0 # Adversarial temperature
LEARNING_RATE=0.0001
REGULARIZATION=0.0
MAX_STEPS=100000
TEST_BATCH_SIZE=16 # Batch size for validation and testing
SAMPLING_METHOD=gaussian # Example: 'uniform' or 'gaussian'
NCLUSTERS=100 # For Gaussian sampling K-means
VARIANCE=290 # For Gaussian sampling variance
REORDER_STEPS=1000 # For Gaussian sampling reorder
SUB_LOSS_WEIGHT=1.0
SUB_REGULARIZATION=0.1

# Early Stopping Parameters
EARLY_STOPPING_PATIENCE=2 # Number of validation checks with no improvement. Set to 0 to disable.
EARLY_STOPPING_METRIC="HITS@10" # Metric to monitor: MRR, MR, HITS@1, HITS@3, HITS@10
VALID_STEPS=5000 # Frequency of validation checks (also used by early stopping)


#LossMethod
LOSS_METHOD='--tans'
TANS_TEMPRETURE=1.0

# Create save directory if it doesn't exist
mkdir -p $SAVE

if [ $MODE == "train" ]
then

echo "Start Training......"
echo "Data Path: $FULL_DATA_PATH"
echo "Save Path: $SAVE"
echo "Model: $MODEL"
echo "Max Steps: $MAX_STEPS"
echo "Early Stopping Patience: $EARLY_STOPPING_PATIENCE (Metric: $EARLY_STOPPING_METRIC, Freq: $VALID_STEPS steps)"

CUDA_VISIBLE_DEVICES=$GPU_DEVICE python -u $CODE_PATH/run.py --do_train \
    --cuda \
    --do_valid \
    --do_test \
    --data_path $FULL_DATA_PATH \
    --model $MODEL \
    -n $NEGATIVE_SAMPLE_SIZE -b $BATCH_SIZE -d $HIDDEN_DIM \
    -g $GAMMA -a $ALPHA -r $REGULARIZATION \
    -lr $LEARNING_RATE --max_steps $MAX_STEPS \
    -save $SAVE --test_batch_size $TEST_BATCH_SIZE \
    --valid_steps $VALID_STEPS \
    -sm $SAMPLING_METHOD \
    -k $NCLUSTERS  -v $VARIANCE --reorder_steps $REORDER_STEPS \
    -adv \
    --early_stopping_patience $EARLY_STOPPING_PATIENCE \
    --early_stopping_metric $EARLY_STOPPING_METRIC \
    ${LOSS_METHOD} -utp $TANS_TEMPRETURE

elif [ $MODE == "valid" ]
then

echo "Start Evaluation on Valid Data Set......"
echo "Loading model from: $SAVE"

CUDA_VISIBLE_DEVICES=$GPU_DEVICE python -u $CODE_PATH/run.py --do_valid --cuda -init $SAVE \
    --test_batch_size $TEST_BATCH_SIZE

elif [ $MODE == "test" ]
then

echo "Start Evaluation on Test Data Set......"
echo "Loading model from: $SAVE"
# When testing, it's often preferred to load the 'best_checkpoint.pth' if early stopping was used.
# You might need to adjust this logic based on how you want to select the model for testing.
# For now, it loads the regular 'checkpoint'.
# If you always want to test the best model from early stopping, you could change -init $SAVE to
# -init $SAVE (and modify run.py to look for best_checkpoint.pth if -init is a directory and --do_test is set)
# or explicitly point to $SAVE/best_checkpoint.pth IF IT EXISTS.
# The current Python script modification should handle loading the best model automatically at the end of training
# if early stopping was active, so $SAVE (which points to the directory) should be fine for -init,
# as the final 'checkpoint' might be the best one or the best_checkpoint.pth is loaded internally.
# Let's assume the python script will load the best model if available from the directory for testing.

CUDA_VISIBLE_DEVICES=$GPU_DEVICE python -u $CODE_PATH/run.py --do_test --cuda -init $SAVE \
    --test_batch_size $TEST_BATCH_SIZE

else
   echo "Unknown MODE" $MODE
fi
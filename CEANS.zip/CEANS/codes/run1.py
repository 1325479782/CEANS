#!/usr/bin/python3

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import json
import logging
import os
from sklearn.cluster import KMeans, AgglomerativeClustering

import numpy as np
import torch

from torch.utils.data import DataLoader
import torch.nn.functional as F

import models

from dataloader import TrainDataset, TestDataset
from dataloader import BidirectionalOneShotIterator

from collections import defaultdict # Add this import


def parse_args(args=None):
    parser = argparse.ArgumentParser(
        description='Entity Aware Negative Sampling for KGE',
        usage='train.py [<args>] [-h | --help]'
    )

    parser.add_argument('--cuda', action='store_true', help='use GPU')

    parser.add_argument('--do_train', action='store_true')
    parser.add_argument('--do_valid', action='store_true')
    parser.add_argument('--do_test', action='store_true')
    parser.add_argument('--evaluate_train', action='store_true', help='Evaluate on training data')

    parser.add_argument('--data_path', type=str, default=None)
    parser.add_argument('--model', default='TransE', type=str)
    parser.add_argument('-de', '--double_entity_embedding', action='store_true')
    parser.add_argument('-dr', '--double_relation_embedding', action='store_true')

    parser.add_argument('-n', '--negative_sample_size', default=128, type=int)
    parser.add_argument('-d', '--hidden_dim', default=500, type=int)
    parser.add_argument('-g', '--gamma', default=12.0, type=float)
    parser.add_argument('-adv', '--negative_adversarial_sampling', action='store_true')
    parser.add_argument('-a', '--adversarial_temperature', default=1.0, type=float)
    parser.add_argument('-b', '--batch_size', default=1024, type=int)
    parser.add_argument('-r', '--regularization', default=0.0, type=float)
    parser.add_argument('--test_batch_size', default=4, type=int, help='valid/test batch size')
    parser.add_argument('--uni_weight', action='store_true',
                        help='Otherwise use subsampling weighting like in word2vec')

    parser.add_argument('-sm', '--sampling_method', type=str, default='uniform')
    parser.add_argument('-tn', '--only_true_negative', action='store_true')
    parser.add_argument('-sub', '--substitution_loss', action='store_true')
    parser.add_argument('-k', type=int, default=100)
    parser.add_argument('-v', '--variance', type=int, default=290)
    parser.add_argument('-subl', '--sub_loss_weight', type=float, default=1.0)
    parser.add_argument('-subr', '--sub_regularization', type=float, default=0.1)

    parser.add_argument('-lr', '--learning_rate', default=0.0001, type=float)
    parser.add_argument('-cpu', '--cpu_num', default=10, type=int)
    parser.add_argument('-init', '--init_checkpoint', default=None, type=str)
    parser.add_argument('-save', '--save_path', default=None, type=str)
    parser.add_argument('--max_steps', default=100000, type=int)
    parser.add_argument('--warm_up_steps', default=None, type=int)

    parser.add_argument('--save_checkpoint_steps', default=5000, type=int)
    parser.add_argument('--valid_steps', default=10000, type=int)
    parser.add_argument('--log_steps', default=500, type=int, help='train log every xx steps')
    parser.add_argument('--test_log_steps', default=1000, type=int, help='valid/test log every xx steps')
    parser.add_argument('--reorder_steps', default=1000, type=int, help='re-ordering embedding ids every xx steps')

    parser.add_argument('--nentity', type=int, default=0, help='DO NOT MANUALLY SET')
    parser.add_argument('--nrelation', type=int, default=0, help='DO NOT MANUALLY SET')

    # Early stopping arguments
    parser.add_argument('--early_stopping_patience', default=2, type=int,
                        help='Number of validation checks with no improvement to trigger early stopping. 0 to disable.')
    parser.add_argument('--early_stopping_metric', default='HITS@10', type=str,
                        choices=['MRR', 'MR', 'HITS@1', 'HITS@3', 'HITS@10'],
                        help='Metric to monitor for early stopping.')

    # Curriculum Learning Arguments
    parser.add_argument('--curriculum_learning', action='store_true', help='Enable curriculum learning.')
    parser.add_argument('--cl_pacing_function', type=str, default='geometric',
                        choices=['linear', 'root', 'root-p', 'geometric'],
                        help='Pacing function for curriculum learning.')
    parser.add_argument('--cl_start_percentage', type=float, default=None,
                        help='Initial percentage of data to use (p0). If None, calculated from Z-count=0 triples.')
    parser.add_argument('--cl_T_grow', type=int, default=10,
                        help='Number of epochs/periods over which the curriculum grows to 100% data.')
    parser.add_argument('--cl_update_steps', type=int, default=10000,  # Or make it epoch-based
                        help='Update curriculum (and re-init DataLoader) every xx steps.')
    parser.add_argument('--cl_min_z_count_for_hard', type=int, default=1,
                        # Triples with Z-count < this are 'easy' for p0 calc
                        help='Z-count threshold to consider a triple not easy for p0 calculation.')

    return parser.parse_args(args)


# Helper function to calculate Z-counts for all training triples
def calculate_z_counts_for_triples(train_triples, nrelation):
    logging.info("Calculating Z-counts for training triples...")
    train_triple_set = set(train_triples)
    triple_to_z_count = defaultdict(int)

    # For performance, pre-filter potential (h,r,e1), (e1,r,e2), (e2,r,t)
    # This can be quite slow for large graphs if done naively.
    # A more optimized way would involve graph libraries or specific data structures.
    # For simplicity, a direct check:

    # Pre-build dictionaries for faster lookups:
    # hr_to_e1s: (h, r) -> set of e1
    # e1r_to_e2s: (e1, r) -> set of e2
    # e2r_to_ts: (e2, r) -> set of t (not strictly needed if we check (e2,r,t) in train_triple_set)

    # Pre-build dictionaries for faster lookups:
    # hr_to_e1_set: (h, r) -> set of e1  (where e1 is the tail of the first triple)
    # e1r_to_e2_set: (e1, r) -> set of e2 (where e1 is the head and e2 is the tail of the second triple)
    # e2r_to_t_set: (e2, r) -> set of t  (where e2 is the head and t is the tail of the third triple)
    # For Z-path (h,r,e1), (e1,r,e2), (e2,r,t)

    # Map (head, relation) to a set of tails
    hr_to_tails = defaultdict(set)
    for h_i, r_i, t_i in train_triples:
        hr_to_tails[(h_i, r_i)].add(t_i)

    num_triples_processed = 0
    total_triples = len(train_triples)

    for h_orig, r_orig, t_orig in train_triples:
        count = 0
        # Find e1 such that (h_orig, r_orig, e1) exists
        if (h_orig, r_orig) in hr_to_tails:
            for e1 in hr_to_tails[(h_orig, r_orig)]:  # e1 is a tail of (h_orig, r_orig, ?)
                # Find e2 such that (e1, r_orig, e2) exists
                if (e1, r_orig) in hr_to_tails:  # e1 is now a head
                    for e2 in hr_to_tails[(e1, r_orig)]:  # e2 is a tail of (e1, r_orig, ?)
                        # Check if (e2, r_orig, t_orig) exists
                        if (
                        e2, r_orig, t_orig) in train_triple_set:  # Or check hr_to_tails[(e2, r_orig)] and t_orig in it
                            count += 1
        triple_to_z_count[(h_orig, r_orig, t_orig)] = count
        num_triples_processed += 1
        if num_triples_processed % 10000 == 0:
            logging.info(f"Z-counts: Processed {num_triples_processed}/{total_triples} triples.")

    logging.info("Finished calculating Z-counts.")
    return triple_to_z_count


def sort_triples_by_z_counts(train_triples, triple_to_z_count):
    logging.info("Sorting triples by Z-counts...")
    # Sort primarily by Z-count, secondarily by original order (implicit) or a hash for stability
    sorted_triples = sorted(train_triples, key=lambda t: triple_to_z_count[t])
    logging.info("Finished sorting triples.")
    return sorted_triples


def get_pacing_function_value(current_progress_ratio, p0, func_type='geometric', T_grow=10.0):
    """
    Calculates the percentage of data to use based on the pacing function.
    current_progress_ratio: Ranges from 0 to 1, indicating how far into T_grow we are.
    p0: Initial percentage of data.
    func_type: Type of pacing function.
    T_grow: Not directly used here as current_progress_ratio = current_epoch / T_grow
    """
    lambda_t = 0.0
    # Ensure current_progress_ratio is between 0 and 1
    t_norm = min(1.0, max(0.0, current_progress_ratio))

    if func_type == 'linear':
        # Po + (1/Po) * min(1, lambda_0_slope * t / T_grow) -- This seems off from paper's notation
        # Paper: p0 + (1/p0) * min(1, lambda0 + t/Tgrow) where p0 is initial value, 1/p0 is a typo, should be (1-p0)
        # Simpler interpretation: p_t = p_0 + (1-p_0) * (t / T_grow)
        lambda_t = p0 + (1 - p0) * t_norm
    elif func_type == 'root':  # Corresponds to Root in paper
        # p_t = p_0 + (1-p_0) * sqrt(t / T_grow)
        lambda_t = p0 + (1 - p0) * np.sqrt(t_norm)
    elif func_type == 'root-p':  # Corresponds to Root-p in paper (assuming lambda_0 is small or 0)
        # p_t = p_0 + (1-p_0) * (t / T_grow)^(1/p) where p is a power, e.g., p=2 is sqrt
        # Let's assume p=2 for simplicity if not specified, making it same as root
        # The paper formula is p0 + (1/p0) * min(1, ((1-lambda0)/Tgrow * t + lambda0^p)^(1/p)) -- complex
        # Simplified: p0 + (1-p0) * ( ( (1-lambda0_const) * t_norm + lambda0_const**p )**(1/p) )
        # For now, using a simpler Root, as Root-p in paper is complex and involves lambda0 as a slope
        lambda_t = p0 + (1 - p0) * np.sqrt(t_norm)  # Same as root for now
    elif func_type == 'geometric':
        # p_t = p_0 + (1-p_0) * ( (lambda_0_geom ^ (1 - t/T_grow)) if t/T_grow < 1 else 1.0 )
        # lambda_0_geom is a small starting value for the (0,1) part, e.g., 0.01 or 0.1
        # The paper's formula for geometric is p0 + (1/p0) * min(1, 2^( (log2(1-log2(lambda0)) / T_grow) * t + log2(lambda0) ) )
        # A common geometric pacing: p_t = total_size * (initial_rate ^ (1 - t_norm))
        # Let's use the paper's logic where lambda_t = p0 initially, and grows.
        # lambda_t = target_p0 + (1 - target_p0) * (some_small_val ^ (1 - t_norm) )
        # If we want to reach 1.0 from p0:
        if t_norm < 1.0:
            # This ensures it starts at p0 and grows towards 1.0
            # We need a base for the exponentiation. Let base = 0.01 (small value)
            # When t_norm=0, (1-p0) * base^1. When t_norm=1, (1-p0)*base^0 = (1-p0).
            # So, lambda_t = p0 + (1-p0) * (1 - base**(1-t_norm))
            # Or, more directly: lambda_t = 1 - (1 - p0) * (some_base ** t_norm) where some_base makes it start at p0 when t_norm=0 (not possible with p0>0)
            # Let's use a simpler growth: lambda_t starts at p0 and grows.
            # The amount to grow is (1-p0). The growth factor is (factor^t_norm).
            # p_t = p0 + (1-p0) * (factor_for_growth_shape ^ t_norm)
            # A simple geometric approach: lambda_t = p0 * ( (1.0/p0)**t_norm ) , capped at 1.0
            # This ensures lambda_t = p0 at t_norm=0 and lambda_t = 1.0 at t_norm=1.
            if p0 > 0:  # Avoid division by zero or log of zero if p0 is 0
                lambda_t = p0 * ((1.0 / p0) ** t_norm)
            else:  # if p0 is 0, then linear growth from 0
                lambda_t = t_norm

        else:
            lambda_t = 1.0
    else:
        raise ValueError(f"Unsupported pacing function type: {func_type}")

    return min(1.0, max(p0, lambda_t))  # Ensure it's at least p0 and at most 1.0


def override_config(args):
    '''
    Override model and data configuration
    '''

    with open(os.path.join(args.init_checkpoint, 'config.json'), 'r') as fjson:
        argparse_dict = json.load(fjson)

    # Do not override early stopping parameters from a checkpoint by default
    # User should specify them if they want to continue with early stopping
    # Or, we can add them to the config if they were originally set
    # For simplicity, let's not override them from the checkpoint's config.json

    if args.data_path is None:
        args.data_path = argparse_dict['data_path']
    args.model = argparse_dict['model']
    args.double_entity_embedding = argparse_dict['double_entity_embedding']
    args.double_relation_embedding = argparse_dict['double_relation_embedding']
    args.hidden_dim = argparse_dict['hidden_dim']
    args.test_batch_size = argparse_dict['test_batch_size']


def save_model(model, optimizer, save_variable_list, args, is_best=False):
    '''
    Save the parameters of the model and the optimizer,
    as well as some other variables such as step and learning_rate
    '''

    argparse_dict = vars(args)
    if not os.path.exists(args.save_path):
        os.makedirs(args.save_path)

    with open(os.path.join(args.save_path, 'config.json'), 'w') as fjson:
        json.dump(argparse_dict, fjson)

    checkpoint_name = 'best_checkpoint.pth' if is_best else 'checkpoint'

    # Save full checkpoint (including optimizer) only for regular checkpoints,
    # for best model, only model_state_dict is usually enough for inference/fine-tuning.
    # However, to keep it simple and allow resuming from best, let's save optimizer too.
    save_dict = {
        **save_variable_list,
        'model_state_dict': model.state_dict()
    }
    if optimizer is not None and not is_best:  # Only save optimizer for regular checkpoints
        save_dict['optimizer_state_dict'] = optimizer.state_dict()

    torch.save(save_dict, os.path.join(args.save_path, checkpoint_name))

    if not is_best:  # Only save embeddings for regular checkpoints to avoid too much disk I/O
        entity_embedding = model.entity_embedding.detach().cpu().numpy()
        np.save(
            os.path.join(args.save_path, 'entity_embedding'),
            entity_embedding
        )

        relation_embedding = model.relation_embedding.detach().cpu().numpy()
        np.save(
            os.path.join(args.save_path, 'relation_embedding'),
            relation_embedding
        )


def read_triple(file_path, entity2id, relation2id):
    '''
    Read triples and map them into ids.
    '''
    triples = []
    with open(file_path) as fin:
        for line in fin:
            h, r, t = line.strip().split('\t')
            triples.append((entity2id[h], relation2id[r], entity2id[t]))
    return triples


def set_logger(args):
    '''
    Write logs to checkpoint and console
    '''

    if args.do_train:
        log_file = os.path.join(args.save_path or args.init_checkpoint or ".", 'train.log')
    else:
        log_file = os.path.join(args.save_path or args.init_checkpoint or ".", 'test.log')

    if args.save_path and not os.path.exists(args.save_path):
        os.makedirs(args.save_path)

    logging.basicConfig(
        format='%(asctime)s %(levelname)-8s %(message)s',
        level=logging.INFO,
        datefmt='%Y-%m-%d %H:%M:%S',
        filename=log_file,
        filemode='w'
    )
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s %(levelname)-8s %(message)s')
    console.setFormatter(formatter)
    logging.getLogger('').addHandler(console)


def log_metrics(mode, step, metrics):
    '''
    Print the evaluation logs
    '''
    for metric in metrics:
        logging.info('%s %s at step %d: %f' % (mode, metric, step, metrics[metric]))


def train_step(model, optimizer, train_iterator, args):
    '''
    A single train step. Apply back-propation and return the loss
    '''

    model.train()

    optimizer.zero_grad()

    positive_sample, negative_sample, false_neg_mask, subsampling_weight, mode = next(train_iterator)

    if args.cuda:
        positive_sample = positive_sample.cuda()
        negative_sample = negative_sample.cuda()
        if false_neg_mask is not None:  # false_neg_mask can be None if only_true_negative
            false_neg_mask = false_neg_mask.cuda()
        subsampling_weight = subsampling_weight.cuda()

    negative_score = model((positive_sample, negative_sample), mode=mode)

    sub_loss = 0
    if args.substitution_loss:
        sub_rel = torch.zeros(positive_sample.size(0), 1, dtype=torch.long) + args.nrelation
        if args.cuda:
            sub_rel = sub_rel.cuda()
        if mode == 'head-batch':
            subs_positive_sample = torch.cat([positive_sample[:, 0:1], sub_rel, positive_sample[:, 2:]], dim=-1)
            negative_sub_score1 = model((subs_positive_sample, negative_sample), mode='tail-batch')
            subs_positive_sample = torch.cat([positive_sample[:, 2:], sub_rel, positive_sample[:, 0:1]], dim=-1)
            negative_sub_score2 = model((subs_positive_sample, negative_sample), mode='head-batch')
        else:
            subs_positive_sample = torch.cat([positive_sample[:, 2:], sub_rel, positive_sample[:, 0:1]], dim=-1)
            negative_sub_score1 = model((subs_positive_sample, negative_sample), mode='tail-batch')
            subs_positive_sample = torch.cat([positive_sample[:, 0:1], sub_rel, positive_sample[:, 2:]], dim=-1)
            negative_sub_score2 = model((subs_positive_sample, negative_sample), mode='head-batch')

        neg_sub_score = 0.5 * (negative_sub_score1 + negative_sub_score2)
        negative_score = negative_score - args.sub_regularization * neg_sub_score

        if false_neg_mask is not None:
            false_neg_add_mask = torch.zeros_like(false_neg_mask).masked_fill_(false_neg_mask == 1,
                                                                               float('-inf')).detach()
            if args.cuda:
                false_neg_add_mask = false_neg_add_mask.cuda()
            negative_score = negative_score + false_neg_add_mask

            sub_loss += args.sub_loss_weight * \
                        ((-1 * torch.nn.functional.logsigmoid(neg_sub_score.squeeze())) *
                         false_neg_mask.squeeze()).sum() / \
                        (false_neg_mask.squeeze().sum() + 1e-20)
        else:  # if false_neg_mask is None, cannot compute this part of sub_loss
            # This case should be handled or documented: substitution loss may not work well with only_true_negative
            logging.warning(
                "Substitution loss with only_true_negative might behave unexpectedly without false_neg_mask.")

        sub_loss += args.sub_regularization * torch.abs(neg_sub_score.unsqueeze(-1)).mean()

    if args.negative_adversarial_sampling:
        # In self-adversarial sampling, we do not apply back-propagation on the sampling weight
        neg_weights = F.softmax(negative_score * args.adversarial_temperature, dim=1).detach()
        negative_score = (neg_weights * F.logsigmoid(-negative_score)).sum(dim=1)
    else:
        negative_score = F.logsigmoid(-negative_score).mean(dim=1)

    positive_score = model(positive_sample)

    positive_score = F.logsigmoid(positive_score).squeeze(dim=1)

    if args.uni_weight:
        positive_sample_loss = - positive_score.mean()
        negative_sample_loss = - negative_score.mean()
    else:
        positive_sample_loss = - (subsampling_weight * positive_score).sum() / subsampling_weight.sum()
        negative_sample_loss = - (subsampling_weight * negative_score).sum() / subsampling_weight.sum()

    loss = (positive_sample_loss + negative_sample_loss) / 2
    loss += sub_loss

    if args.regularization != 0.0:
        # Use L3 regularization for ComplEx and DistMult
        regularization = args.regularization * (
                model.entity_embedding.norm(p=3) ** 3 +
                model.relation_embedding.norm(p=3).norm(p=3) ** 3
            # This seems like a typo, likely just model.relation_embedding.norm(p=3)**3
        )
        # Corrected:
        # regularization = args.regularization * (
        #         model.entity_embedding.norm(p=3)**3 +
        #         model.relation_embedding.norm(p=3)**3
        # )
        loss = loss + regularization
        regularization_log = {'regularization': regularization.item()}
    else:
        regularization_log = {}

    if torch.isnan(loss).item():
        # when only get false negative samples, do not update parameters
        loss = torch.tensor([0.0], device=positive_sample.device if args.cuda else 'cpu')  # Ensure device consistency
        positive_sample_loss = torch.tensor([0.0], device=positive_sample.device if args.cuda else 'cpu')
        negative_sample_loss = torch.tensor([0.0], device=positive_sample.device if args.cuda else 'cpu')
    else:
        loss.backward()
        optimizer.step()

    log = {
        **regularization_log,
        'positive_sample_loss': positive_sample_loss.item(),
        'negative_sample_loss': negative_sample_loss.item(),
        'loss': loss.item()
    }
    if args.substitution_loss:
        log['substitution_loss'] = sub_loss.item() if isinstance(sub_loss, torch.Tensor) else sub_loss

    return log


def test_step(model, test_triples, all_true_triples, args):
    '''
    Evaluate the model on test or valid datasets
    '''

    model.eval()
    test_dataloader_head = DataLoader(
        TestDataset(
            test_triples,
            all_true_triples,
            args.nentity,
            args.nrelation,
            'head-batch'
        ),
        batch_size=args.test_batch_size,
        num_workers=max(1, args.cpu_num // 2),
        collate_fn=TestDataset.collate_fn
    )

    test_dataloader_tail = DataLoader(
        TestDataset(
            test_triples,
            all_true_triples,
            args.nentity,
            args.nrelation,
            'tail-batch'
        ),
        batch_size=args.test_batch_size,
        num_workers=max(1, args.cpu_num // 2),
        collate_fn=TestDataset.collate_fn
    )

    test_dataset_list = [test_dataloader_head, test_dataloader_tail]
    logs = []
    step_count = 0  # Renamed from 'step' to avoid conflict with outer scope 'step'
    total_steps = sum([len(dataset) for dataset in test_dataset_list])

    with torch.no_grad():
        for test_dataset in test_dataset_list:
            for positive_sample, negative_sample, filter_bias, mode in test_dataset:
                if args.cuda:
                    positive_sample = positive_sample.cuda()
                    negative_sample = negative_sample.cuda()
                    filter_bias = filter_bias.cuda()

                batch_size = positive_sample.size(0)
                score = model((positive_sample, negative_sample), mode)
                score += filter_bias
                argsort = torch.argsort(score, dim=1, descending=True)

                if mode == 'head-batch':
                    positive_arg = positive_sample[:, 0]
                elif mode == 'tail-batch':
                    positive_arg = positive_sample[:, 2]
                else:
                    raise ValueError('mode %s not supported' % mode)

                for i in range(batch_size):
                    ranking = (argsort[i, :] == positive_arg[i]).nonzero()
                    assert ranking.size(0) == 1
                    ranking = 1 + ranking.item()
                    logs.append({
                        'MRR': 1.0 / ranking,
                        'MR': float(ranking),
                        'HITS@1': 1.0 if ranking <= 1 else 0.0,
                        'HITS@3': 1.0 if ranking <= 3 else 0.0,
                        'HITS@10': 1.0 if ranking <= 10 else 0.0,
                    })

                if step_count % args.test_log_steps == 0:
                    logging.info('Evaluating the model... (%d/%d)' % (step_count, total_steps))
                step_count += 1

    metrics = {}
    if not logs:  # Handle case with empty test_triples
        logging.warning("No logs generated during test_step, possibly empty test_triples.")
        return {'MRR': 0.0, 'MR': float('inf'), 'HITS@1': 0.0, 'HITS@3': 0.0, 'HITS@10': 0.0}

    for metric in logs[0].keys():
        metrics[metric] = sum([log[metric] for log in logs]) / len(logs)
    return metrics


def reorder_embeddings(model, train_dataset_head, train_dataset_tail, args):
    # Step 1: Get entity embeddings
    # Assuming entity_proxy.get_real_id(vid) gives the original real ID
    # and we want to cluster based on the current embeddings of these real IDs.
    # The virtual IDs in entity_proxy are 0 to nentity-1 initially.
    # After reordering, these virtual IDs (0 to nentity-1) will map to *newly ordered* real IDs.
    # The `ids` tensor should hold the real entity IDs whose embeddings we want to cluster.
    # The `old_embeddings_tensor` will then be the embeddings corresponding to these real IDs.
    # The `labels` from clustering will be of the same length as `ids` and `old_embeddings_tensor`.

    # The current code seems to get embeddings for virtual IDs 0..nentity-1,
    # which through proxy.get_real_id() gives all unique real IDs. This is correct.
    ids_to_get_embeddings_for = torch.tensor(
        [train_dataset_head.entity_proxy.get_real_id(virtual_idx) for virtual_idx in range(args.nentity)],
        dtype=torch.long
    )
    if args.cuda:
        ids_to_get_embeddings_for = ids_to_get_embeddings_for.cuda()

    current_entity_embeddings_tensor = model.get_ent_embeddings(ids_to_get_embeddings_for)
    current_entity_embeddings_np = current_entity_embeddings_tensor.cpu().detach().numpy()

    # Step 2: Perform clustering


    cluster_model = AgglomerativeClustering(n_clusters=args.k, linkage='ward')


    labels = cluster_model.fit_predict(current_entity_embeddings_np)


    # Step 3: Calculate cluster centers (centroids)
    cluster_centers_list = []
    if args.k > 0:
        for i in range(args.k):
            # Entities belonging to cluster i
            # `labels` corresponds to the order of `current_entity_embeddings_tensor`
            entities_in_cluster_i_embeddings = current_entity_embeddings_tensor[labels == i]
            if entities_in_cluster_i_embeddings.size(0) > 0:
                cluster_centers_list.append(entities_in_cluster_i_embeddings.mean(dim=0))
            else:
                logging.warning(f"Cluster {i} is empty for {args.clustering_method} clustering.")
                # Fallback: use a zero vector. This might affect ordering.
                cluster_centers_list.append(torch.zeros_like(current_entity_embeddings_tensor[0]))

        if not cluster_centers_list:
            logging.error("All cluster centers are empty (e.g. all clusters were empty). Skipping reordering.")
            return
        centers_of_clusters = torch.stack(cluster_centers_list)
        if args.cuda and centers_of_clusters.device.type != 'cuda':
            centers_of_clusters = centers_of_clusters.cuda()
    else:  # args.k <= 0, no reordering needed based on clusters
        return

    # Step 4: Order the clusters (same logic as before, using calculated centroids)
    # `cluster_order_map` maps: original_cluster_label (0 to k-1) -> new_sequential_order (0 to k-1)
    cluster_order_map = {}
    order_idx = 0

    if centers_of_clusters.size(0) > 0:  # Should be true if args.k > 0 and cluster_centers_list was populated
        processing_centers = centers_of_clusters.clone()
        # processing_labels_are_original_cluster_indices (0 to k-1)
        processing_labels_are_original_cluster_indices = list(range(args.k))

        # Start with the first cluster (original label 0)
        # current_center_is_of_original_cluster_idx = processing_labels_are_original_cluster_indices[0]
        # current_center_vec = processing_centers[0]
        # cluster_order_map[current_center_is_of_original_cluster_idx] = order_idx
        # order_idx += 1

        # # Remove the starting center and its label
        # processing_centers = processing_centers[1:]
        # processing_labels_are_original_cluster_indices = processing_labels_are_original_cluster_indices[1:]

        # Robust start:
        start_node_original_label = 0  # This is the original cluster index (0 to k-1)
        current_center_vec = processing_centers[start_node_original_label]
        cluster_order_map[start_node_original_label] = order_idx
        order_idx += 1

        # Remove the starting center and its label by creating new lists/tensors
        temp_centers = []
        temp_labels = []
        for i in range(processing_centers.size(0)):
            if i != start_node_original_label:
                temp_centers.append(processing_centers[i])
                temp_labels.append(processing_labels_are_original_cluster_indices[i])

        if not temp_centers:  # Only one cluster
            processing_centers = torch.empty(0, centers_of_clusters.size(1), device=centers_of_clusters.device)
        else:
            processing_centers = torch.stack(temp_centers)
        processing_labels_are_original_cluster_indices = temp_labels

        while processing_centers.size(0) > 0:
            dists = torch.nn.functional.pairwise_distance(current_center_vec.unsqueeze(0), processing_centers)
            _, top_i_in_processing = dists.topk(1, largest=False)
            top_i_in_processing = top_i_in_processing.item()

            current_center_vec = processing_centers[top_i_in_processing]
            # This is the original cluster label for the center we just picked
            original_label_of_picked_center = processing_labels_are_original_cluster_indices[top_i_in_processing]

            cluster_order_map[original_label_of_picked_center] = order_idx
            order_idx += 1

            # Remove the chosen center and its label
            processing_centers = torch.cat(
                [processing_centers[:top_i_in_processing], processing_centers[top_i_in_processing + 1:]], dim=0)
            processing_labels_are_original_cluster_indices.pop(top_i_in_processing)

    # Step 5: Create the mapping from old virtual IDs to new virtual IDs
    if args.k > 0 and cluster_order_map and len(labels) == args.nentity:
        # `labels` contains the original cluster label (0 to k-1) for each entity (entity 0, entity 1, ..., entity N-1)
        # `entity_virtual_id` here is the implicit index from 0 to nentity-1 before reordering.

        # For each entity (identified by its implicit old_virtual_id from 0 to N-1),
        # get its original cluster label: `labels[old_virtual_id]`
        # then get the new sequential order of that cluster: `cluster_order_map[labels[old_virtual_id]]`
        # This gives `new_cluster_order_for_entity_old_virtual_id`.

        try:
            # `entity_cluster_sequential_order`[i] = the new sequential order of the cluster that entity `i` (old virtual ID) belongs to.
            entity_cluster_sequential_order = [cluster_order_map[original_cluster_label_for_entity] for
                                               original_cluster_label_for_entity in labels]
        except KeyError as e:
            logging.error(f"KeyError in cluster_order_map during entity label mapping: {e}. "
                          f"Original cluster labels present in entities: {np.unique(labels)}. "
                          f"Cluster_order_map keys: {list(cluster_order_map.keys())}")
            return

        # We want to sort entities based on `entity_cluster_sequential_order`.
        # `torch.argsort` gives the indices that would sort the array.
        # `sorted_old_virtual_ids`[j] = the old_virtual_id of the entity that is at the j-th position in the new global order.
        # Example: if entity_cluster_sequential_order = [1, 0, 1, 2, 0] (for entities 0,1,2,3,4)
        # Sorted order of labels: 0, 0, 1, 1, 2
        # Corresponding old_virtual_ids: 1, 4, 0, 2, 3
        # So, sorted_old_virtual_ids should be [1, 4, 0, 2, 3]

        # To ensure stable sort (entities within the same new cluster order maintain their relative original virtual ID order):
        # Create pairs of (cluster_order, old_virtual_id)
        decorated_entities = []
        for old_virtual_id in range(args.nentity):
            decorated_entities.append((entity_cluster_sequential_order[old_virtual_id], old_virtual_id))

        decorated_entities.sort()  # Sorts by cluster_order, then by old_virtual_id

        sorted_old_virtual_ids = [old_vid for cluster_ord, old_vid in decorated_entities]

        old_virtual_id_to_new_virtual_id_map = {}
        for new_virtual_id, old_virtual_id_val in enumerate(sorted_old_virtual_ids):
            old_virtual_id_to_new_virtual_id_map[old_virtual_id_val] = new_virtual_id

        train_dataset_head.update_proxy(old_virtual_id_to_new_virtual_id_map)
        train_dataset_tail.update_proxy(old_virtual_id_to_new_virtual_id_map)
    elif args.k <= 0:
        # Already handled at the start of clustering
        pass
    elif not cluster_order_map and args.k > 0:
        logging.warning(
            "Cluster order map is empty, skipping reordering proxy. This might happen if cluster ordering failed.")
    elif len(labels) != args.nentity:
        logging.warning(
            f"Number of labels ({len(labels)}) from clustering does not match nentity ({args.nentity}). Skipping reordering proxy.")


from collections import defaultdict


def main(args):
    print(args)
    if (not args.do_train) and (not args.do_valid) and (not args.do_test) and (not args.evaluate_train):
        raise ValueError('one of train/val/test/evaluate_train mode must be choosed.')

    if args.init_checkpoint:
        override_config(args)
    elif args.data_path is None:
        raise ValueError('one of init_checkpoint/data_path must be choosed.')

    if args.do_train and args.save_path is None:
        raise ValueError('If do_train is set, --save_path must be specified to save models and logs.')

    # Create save_path directory if it doesn't exist
    if args.save_path and not os.path.exists(args.save_path):
        os.makedirs(args.save_path)

    set_logger(args)  # Set logger after ensuring save_path exists or is None

    with open(os.path.join(args.data_path, 'entities.dict')) as fin:
        entity2id = dict()
        for line in fin:
            eid, entity = line.strip().split('\t')
            entity2id[entity] = int(eid)

    with open(os.path.join(args.data_path, 'relations.dict')) as fin:
        relation2id = dict()
        for line in fin:
            rid, relation = line.strip().split('\t')
            relation2id[relation] = int(rid)

    nentity = len(entity2id)
    nrelation = len(relation2id)

    args.nentity = nentity
    args.nrelation = nrelation

    logging.info('Model: %s' % args.model)
    logging.info('Data Path: %s' % args.data_path)
    logging.info('#entity: %d' % nentity)
    logging.info('#relation: %d' % nrelation)

    train_triples = read_triple(os.path.join(args.data_path, 'train.txt'), entity2id, relation2id)
    logging.info('#train: %d' % len(train_triples))
    valid_triples = read_triple(os.path.join(args.data_path, 'valid.txt'), entity2id, relation2id)
    logging.info('#valid: %d' % len(valid_triples))
    test_triples = read_triple(os.path.join(args.data_path, 'test.txt'), entity2id, relation2id)
    logging.info('#test: %d' % len(test_triples))

    all_true_triples_for_eval = train_triples + valid_triples + test_triples

    # --- CURRICULUM LEARNING SETUP ---
    all_sorted_train_triples = list(train_triples)  # Default to original if CL not enabled
    p0_cl = 0.0  # Default initial percentage

    if args.curriculum_learning:
        logging.info("--- Curriculum Learning Enabled ---")
        triple_to_z_count = calculate_z_counts_for_triples(train_triples, args.nrelation)
        all_sorted_train_triples = sort_triples_by_z_counts(train_triples, triple_to_z_count)

        if args.cl_start_percentage is not None:
            p0_cl = args.cl_start_percentage
        else:
            # Calculate p0 as percentage of triples with Z-count < cl_min_z_count_for_hard (e.g., Z-count == 0)
            easy_triples_count = sum(
                1 for t in all_sorted_train_triples if triple_to_z_count[t] < args.cl_min_z_count_for_hard)
            if len(all_sorted_train_triples) > 0:
                p0_cl = easy_triples_count / len(all_sorted_train_triples)
            else:
                p0_cl = 0.0  # Should not happen with non-empty train_triples
            logging.info(f"Calculated cl_start_percentage (p0) = {p0_cl:.4f} "
                         f"(based on Z-count < {args.cl_min_z_count_for_hard})")

        if p0_cl == 0.0 and len(all_sorted_train_triples) > 0:
            logging.warning(
                "p0_cl is 0.0. Ensure 'cl_min_z_count_for_hard' is set appropriately or provide 'cl_start_percentage'. Defaulting to small fraction.")
            p0_cl = 0.01  # Ensure some data is used initially if all Z-counts are high

        logging.info(
            f"Pacing function: {args.cl_pacing_function}, T_grow (epochs/periods): {args.cl_T_grow}, Update steps: {args.cl_update_steps}")
    # --- END CURRICULUM LEARNING SETUP ---

    kge_model_class = getattr(models, args.model)
    kge_model = kge_model_class(
        model_name=args.model,
        nentity=nentity,
        nrelation=nrelation,
        hidden_dim=args.hidden_dim,
        gamma=args.gamma,
        double_entity_embedding=args.double_entity_embedding,
        double_relation_embedding=args.double_relation_embedding
    )

    logging.info('Model Parameter Configuration:')
    for name, param in kge_model.named_parameters():
        logging.info('Parameter %s: %s, require_grad = %s' % (name, str(param.size()), str(param.requires_grad)))

    if args.cuda:
        kge_model = kge_model.cuda()

    current_learning_rate = args.learning_rate  # Initialize here
    optimizer = None  # Initialize optimizer to None

    if args.do_train:

        # Initial curriculum setup
        if args.curriculum_learning:
            initial_num_samples = int(p0_cl * len(all_sorted_train_triples))
            logging.info(
                f"Curriculum Learning: Initial number of samples: {initial_num_samples} / {len(all_sorted_train_triples)}")
        else:
            initial_num_samples = len(all_sorted_train_triples)  # Use all data if CL is off

        train_dataset_head = TrainDataset(args, all_sorted_train_triples, nentity, nrelation, 'head-batch',
                                          initial_curriculum_size=initial_num_samples if args.curriculum_learning else None)
        train_dataset_tail = TrainDataset(args, all_sorted_train_triples, nentity, nrelation, 'tail-batch',
                                          initial_curriculum_size=initial_num_samples if args.curriculum_learning else None)

        train_dataloader_head = DataLoader(
            train_dataset_head, batch_size=args.batch_size, shuffle=True,
            num_workers=max(1, args.cpu_num // 2), collate_fn=TrainDataset.collate_fn
        )
        train_dataloader_tail = DataLoader(
            train_dataset_tail, batch_size=args.batch_size, shuffle=True,
            num_workers=max(1, args.cpu_num // 2), collate_fn=TrainDataset.collate_fn
        )
        train_iterator = BidirectionalOneShotIterator(train_dataloader_head, train_dataloader_tail)

        optimizer = torch.optim.Adam(
            filter(lambda p: p.requires_grad, kge_model.parameters()),
            lr=current_learning_rate
        )
        if args.warm_up_steps is None:
            args.warm_up_steps = args.max_steps // 2

    init_step = 0
    best_valid_metric = -float('inf')  # For MRR, HITS@N (higher is better)
    if args.early_stopping_metric == 'MR':  # For MR (lower is better)
        best_valid_metric = float('inf')
    patience_counter = 0

    # Prepare path for saving best model if early stopping is active
    best_model_checkpoint_path = None
    if args.do_train and args.early_stopping_patience > 0 and args.save_path:
        best_model_checkpoint_path = os.path.join(args.save_path, 'best_checkpoint.pth')

    if args.init_checkpoint:
        logging.info('Loading checkpoint %s...' % args.init_checkpoint)
        checkpoint = torch.load(os.path.join(args.init_checkpoint, 'checkpoint'))  # Load regular checkpoint
        init_step = checkpoint['step']
        kge_model.load_state_dict(checkpoint['model_state_dict'])
        if args.do_train:
            current_learning_rate = checkpoint['current_learning_rate']
            args.warm_up_steps = checkpoint['warm_up_steps']  # warm_up_steps is an arg, not a dynamic var
            if 'optimizer_state_dict' in checkpoint and optimizer is not None:
                optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            # Load early stopping state if available and desired
            if 'best_valid_metric' in checkpoint and checkpoint['best_valid_metric'] is not None:
                best_valid_metric = checkpoint['best_valid_metric']
                logging.info(f"Restored best_valid_metric: {best_valid_metric}")
            # patience_counter is reset, as we are resuming.
    else:
        logging.info('Randomly Initializing %s Model...' % args.model)

    step = init_step

    logging.info('Start Training...')
    logging.info('init_step = %d' % init_step)
    logging.info('max_steps = %d' % args.max_steps)
    logging.info('batch_size = %d' % args.batch_size)
    logging.info('negative_adversarial_sampling = %s' % args.negative_adversarial_sampling)
    logging.info('hidden_dim = %d' % args.hidden_dim)
    logging.info('gamma = %f' % args.gamma)
    logging.info('negative_sample_size = %f' % args.negative_sample_size)

    if args.negative_adversarial_sampling:
        logging.info('adversarial_temperature = %f' % args.adversarial_temperature)

    if args.do_train and len(all_sorted_train_triples) > 0 and args.batch_size > 0:
        steps_per_full_epoch = (len(all_sorted_train_triples) + args.batch_size - 1) // args.batch_size
    else:
        steps_per_full_epoch = args.valid_steps  # Fallback

    current_cl_epoch_or_period = 0  # For pacing function calculation relative to T_grow

    if args.do_train:
        logging.info('learning_rate = %f' % current_learning_rate)
        logging.info('warm_up_steps = %d' % args.warm_up_steps)
        if args.early_stopping_patience > 0:
            logging.info(
                f'Early stopping enabled: patience={args.early_stopping_patience}, metric={args.early_stopping_metric}')

        training_logs = []
        early_stopping_triggered = False

        for step in range(init_step, args.max_steps):

            # --- CURRICULUM UPDATE LOGIC ---
            if args.curriculum_learning and step > 0 and step % args.cl_update_steps == 0:
                # current_cl_epoch_or_period = step // steps_per_full_epoch # If T_grow is in epochs
                # Or, treat cl_update_steps as defining a "period" for T_grow
                current_cl_epoch_or_period = (step // args.cl_update_steps)  # progress in terms of update steps

                # Progress ratio: how far are we into the T_grow period
                # If T_grow is number of cl_update_steps periods:
                progress_ratio = min(1.0, current_cl_epoch_or_period / args.cl_T_grow)

                lambda_t = get_pacing_function_value(progress_ratio, p0_cl, args.cl_pacing_function)
                num_samples_to_use = int(lambda_t * len(all_sorted_train_triples))

                logging.info(f"Step {step}: Updating curriculum. Progress: {progress_ratio:.2f}, "
                             f"Lambda_t: {lambda_t:.4f}, Samples: {num_samples_to_use}/{len(all_sorted_train_triples)}")

                # Update datasets
                train_dataset_head.update_curriculum(num_samples_to_use)
                train_dataset_tail.update_curriculum(num_samples_to_use)

                # Re-initialize DataLoaders and Iterator
                # Important: Ensure shuffle=True if desired for the new subset
                if len(train_dataset_head) > 0 and len(train_dataset_tail) > 0:  # Avoid empty dataloaders
                    train_dataloader_head = DataLoader(
                        train_dataset_head, batch_size=args.batch_size, shuffle=True,
                        num_workers=max(1, args.cpu_num // 2), collate_fn=TrainDataset.collate_fn
                    )
                    train_dataloader_tail = DataLoader(
                        train_dataset_tail, batch_size=args.batch_size, shuffle=True,
                        num_workers=max(1, args.cpu_num // 2), collate_fn=TrainDataset.collate_fn
                    )
                    train_iterator = BidirectionalOneShotIterator(train_dataloader_head, train_dataloader_tail)
                else:
                    logging.warning(
                        f"Step {step}: Curriculum update resulted in empty dataset. Skipping DataLoader re-init.")
                    # This might mean p0 or pacing function is too aggressive or T_grow is too short.
                    # The training step below might fail if iterator is exhausted.
                    # Consider breaking or adjusting p0 if this happens often.
            # --- END CURRICULUM UPDATE LOGIC ---

            if len(train_dataset_head) == 0 or len(train_dataset_tail) == 0:
                logging.warning(
                    f"Step {step}: Training dataset is empty, possibly due to curriculum. Skipping train_step.")
                # Optionally, advance step or handle early termination if data remains empty
                if step % args.log_steps == 0:  # Still log something
                    log_metrics('Training average (skipped)', step, {'loss': 0.0})  # Dummy log
                if step % args.valid_steps == 0 and step > 0:  # Still run validation
                    logging.info('Evaluating on Valid Dataset (training skipped due to empty data)...')
                    metrics_val = test_step(kge_model, valid_triples, all_true_triples_for_eval, args)
                    log_metrics('Valid', step, metrics_val)
                continue  # Skip to next step

            log = train_step(kge_model, optimizer, train_iterator, args)
            training_logs.append(log)

            if step >= args.warm_up_steps:  # Use args.warm_up_steps
                current_learning_rate = current_learning_rate / 10
                logging.info('Change learning_rate to %f at step %d' % (current_learning_rate, step))
                optimizer = torch.optim.Adam(
                    filter(lambda p: p.requires_grad, kge_model.parameters()),
                    lr=current_learning_rate
                )
                args.warm_up_steps = args.warm_up_steps * 3  # Update for next potential decay

            if step % args.save_checkpoint_steps == 0 and step > 0:  # Avoid saving at step 0 if init_step is 0
                if args.save_path:
                    save_variable_list = {
                        'step': step,
                        'current_learning_rate': current_learning_rate,
                        'warm_up_steps': args.warm_up_steps,  # save the potentially updated warm_up_steps
                        'best_valid_metric': best_valid_metric if args.early_stopping_patience > 0 else None
                    }
                    save_model(kge_model, optimizer, save_variable_list, args)

            if step % args.log_steps == 0:
                metrics = {}
                for metric_key in training_logs[0].keys():
                    metrics[metric_key] = sum([train_log[metric_key] for train_log in training_logs]) / len(
                        training_logs)
                log_metrics('Training average', step, metrics)
                training_logs = []

            if args.do_valid and step % args.valid_steps == 0 and step > 0:  # Perform validation
                logging.info('Evaluating on Valid Dataset...')
                metrics = test_step(kge_model, valid_triples, all_true_triples_for_eval, args)
                log_metrics('Valid', step, metrics)

                if args.early_stopping_patience > 0 and args.save_path:
                    current_metric_val = metrics[args.early_stopping_metric]
                    logging.info(
                        f"Early stopping check: Current {args.early_stopping_metric} = {current_metric_val:.4f}")

                    improved = False
                    if args.early_stopping_metric == 'MR':  # Lower is better for MR
                        if current_metric_val < best_valid_metric:
                            improved = True
                    else:  # Higher is better for MRR, HITS@N
                        if current_metric_val - best_valid_metric > 0.0001:
                            improved = True

                    if improved:
                        best_valid_metric = current_metric_val
                        patience_counter = 0
                        logging.info(
                            f"New best validation {args.early_stopping_metric}: {best_valid_metric:.4f}. Saving best model.")
                        save_variable_list = {  # Save minimal info for best model
                            'step': step,
                            'current_learning_rate': current_learning_rate,
                            'warm_up_steps': args.warm_up_steps,
                            'best_valid_metric': best_valid_metric
                        }
                        save_model(kge_model, None, save_variable_list, args, is_best=True)  # optimizer=None for best
                    else:
                        patience_counter += 1
                        logging.info(
                            f"No improvement in validation {args.early_stopping_metric} for {patience_counter} validation steps.")

                    if patience_counter >= args.early_stopping_patience:
                        logging.info(
                            f"Early stopping triggered at step {step} after {args.early_stopping_patience} validation checks without improvement.")
                        early_stopping_triggered = True
                        break  # Exit training loop

            if args.sampling_method == 'gaussian' and step % args.reorder_steps == 0 and args.k > 0:
                # logging.info(f"Reordering embeddings at step {step}...")
                reorder_embeddings(kge_model, train_dataset_head, train_dataset_tail, args) # Pass all triples

        # After training loop (either completed or early stopped)
        if args.save_path:  # Save final model state
            save_variable_list = {
                'step': step,
                'current_learning_rate': current_learning_rate,
                'warm_up_steps': args.warm_up_steps,
                'best_valid_metric': best_valid_metric if args.early_stopping_patience > 0 else None
            }
            save_model(kge_model, optimizer, save_variable_list, args)  # Save final regular checkpoint

        # If early stopping was triggered and a best model exists, load it for final evaluations
        if early_stopping_triggered and best_model_checkpoint_path and os.path.exists(best_model_checkpoint_path):
            logging.info(f"Loading best model from {best_model_checkpoint_path} for final evaluations.")
            checkpoint = torch.load(best_model_checkpoint_path)
            kge_model.load_state_dict(checkpoint['model_state_dict'])
            logging.info(
                f"Best model (val {args.early_stopping_metric}: {checkpoint.get('best_valid_metric', 'N/A')}) loaded.")
        elif args.early_stopping_patience > 0 and best_model_checkpoint_path and os.path.exists(
                best_model_checkpoint_path):
            # If training finished (not early stopped), but early stopping was active,
            # check if the best recorded model is better than the final model.
            # For simplicity, always load the best model if early stopping was active and a best model was saved.
            logging.info(
                f"Training finished. Loading best recorded model from {best_model_checkpoint_path} for final evaluations.")
            checkpoint = torch.load(best_model_checkpoint_path)
            # Compare current model's valid score vs best score if desired, or just load best
            # For now, just load best if it exists and ES was active.
            kge_model.load_state_dict(checkpoint['model_state_dict'])
            logging.info(
                f"Best model (val {args.early_stopping_metric}: {checkpoint.get('best_valid_metric', 'N/A')}) loaded.")

    # Final Evaluations
    # `step` here refers to the last training step performed or the step at which early stopping occurred.
    # If not training, `step` will be `init_step`.

    if args.do_valid:
        logging.info('Evaluating on Valid Dataset...')
        metrics = test_step(kge_model, valid_triples, all_true_triples_for_eval, args)
        log_metrics('Valid', step, metrics)

    if args.do_test:
        logging.info('Evaluating on Test Dataset...')
        metrics = test_step(kge_model, test_triples, all_true_triples_for_eval, args)
        log_metrics('Test', step, metrics)

    if args.evaluate_train:
        logging.info('Evaluating on Training Dataset...')
        metrics = test_step(kge_model, train_triples, all_true_triples_for_eval, args)
        log_metrics('Train (eval)', step, metrics)  # Changed mode to 'Train (eval)' for clarity


if __name__ == '__main__':
    main(parse_args())

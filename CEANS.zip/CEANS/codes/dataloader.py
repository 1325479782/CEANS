#!/usr/bin/python3

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import torch

from torch.utils.data import Dataset


class EntityIdProxy:
    def __init__(self, nentity):
        self.virtual2real = {}
        self.real2virtual = {}
        for i in range(nentity):
            self.virtual2real[i] = i
            self.real2virtual[i] = i

    def get_real_id(self, virtual_id):
        return self.virtual2real[virtual_id]

    def get_virtual_id(self, real_id):
        return self.real2virtual[real_id]

    def update(self, old2new):
        new_virtual2real = {}
        new_real2virtual = {}
        for real_id, virtual_id in self.real2virtual.items():
            new_real2virtual[real_id] = old2new[virtual_id]
        for real_id, virtual_id in new_real2virtual.items():
            new_virtual2real[virtual_id] = real_id
        self.real2virtual = new_real2virtual
        self.virtual2real = new_virtual2real
        return None


class TrainDataset(Dataset):
    def __init__(self, opts, all_sorted_triples, nentity, nrelation, mode, initial_curriculum_size=None):
        self.opts = opts
        self.all_sorted_triples = all_sorted_triples
        self.nentity = nentity
        self.nrelation = nrelation
        self.negative_sample_size = self.opts.negative_sample_size
        self.mode = mode
        self.entity_proxy = EntityIdProxy(nentity)

        if initial_curriculum_size is not None and initial_curriculum_size < len(self.all_sorted_triples):
            self.triples = self.all_sorted_triples[:initial_curriculum_size]
        else:
            self.triples = list(self.all_sorted_triples)

        self.len = len(self.triples)
        self.triple_set = set(self.triples)

        # CRITICAL: Ensure self.count, self.true_head, self.true_tail are initialized
        # correctly considering the entity_proxy.
        # This typically means:
        # 1. Call static methods TrainDataset.count_frequency(self.triples) and
        #    TrainDataset.get_true_head_and_tail(self.triples) which operate on REAL IDs.
        # 2. Then, convert the results to self.count, self.true_head, self.true_tail
        #    by applying self.entity_proxy.get_virtual_id() to all entity components
        #    in keys and values. This logic should be encapsulated, perhaps in a helper
        #    method called here and in update_curriculum and update_proxy.
        # For now, I'll assume they are correctly populated by the time __getitem__ is called.
        # The original `update_proxy` implies this conversion happens.
        # So, `__init__` should effectively do:
        _real_count = TrainDataset.count_frequency(self.triples)
        _real_true_head, _real_true_tail = TrainDataset.get_true_head_and_tail(self.triples)

        # Convert to virtual-ID based structures
        self.count = {}
        for (e1_real, r_real_or_neg_rel), val in _real_count.items():
            v_e1 = self.entity_proxy.get_virtual_id(e1_real)
            self.count[(v_e1, r_real_or_neg_rel)] = val

        self.true_head = {}
        for (r_real, t_real), h_real_list in _real_true_head.items():
            v_t = self.entity_proxy.get_virtual_id(t_real)
            self.true_head[(r_real, v_t)] = np.array([self.entity_proxy.get_virtual_id(h_r) for h_r in h_real_list])

        self.true_tail = {}
        for (h_real, r_real), t_real_list in _real_true_tail.items():
            v_h = self.entity_proxy.get_virtual_id(h_real)
            self.true_tail[(v_h, r_real)] = np.array([self.entity_proxy.get_virtual_id(t_r) for t_r in t_real_list])

    def __len__(self):
        return self.len

    def __getitem__(self, idx):
        if idx >= self.len:
            raise IndexError("Index out of bounds for current curriculum subset")

        positive_sample_real = self.triples[idx]  # Contains REAL IDs

        head_orig_real, relation_orig_real, tail_orig_real = positive_sample_real

        v_head = self.entity_proxy.get_virtual_id(head_orig_real)
        v_tail = self.entity_proxy.get_virtual_id(tail_orig_real)

        # CORRECTED self.count lookup:
        weight_h_r = self.count.get((v_head, relation_orig_real), 4)
        weight_t_nr = self.count.get((v_tail, -relation_orig_real - 1), 4)
        subsampling_weight = weight_h_r + weight_t_nr
        subsampling_weight = torch.sqrt(1 / torch.Tensor([subsampling_weight]))

        negative_sample_list_virtual = []  # Store virtual IDs
        current_negative_sample_size = 0  # Renamed from negative_sample_size to avoid conflict

        # false_neg_mask should be determined based on the final set of negative_sample_list_virtual
        # The variable `false_neg_mask` within the if/else for sampling methods seems to be for a single batch of generation
        # It needs to be collected or applied to the final concatenated list if `only_true_negative` is False.
        # If `only_true_negative` is True, `false_neg_mask` is just zeros.

        final_false_neg_mask_parts = []

        if self.opts.sampling_method == 'uniform':
            # `negative_sample_virtual` from randint are indices 0 to nentity-1, effectively virtual IDs
            if self.opts.only_true_negative:
                # false_neg_mask is implicitly all zeros for true negatives
                while current_negative_sample_size < self.negative_sample_size:
                    negative_sample_candidates_virtual = np.random.randint(self.nentity,
                                                                           size=self.negative_sample_size * 2)
                    if self.mode == 'head-batch':
                        true_entities_virtual = self.true_head.get((relation_orig_real, v_tail), np.array([]))
                        mask = np.in1d(
                            negative_sample_candidates_virtual,
                            true_entities_virtual,  # VIRTUAL IDs
                            assume_unique=True,
                            invert=True
                        )
                    elif self.mode == 'tail-batch':
                        true_entities_virtual = self.true_tail.get((v_head, relation_orig_real), np.array([]))
                        mask = np.in1d(
                            negative_sample_candidates_virtual,
                            true_entities_virtual,  # VIRTUAL IDs
                            assume_unique=True,
                            invert=True
                        )
                    else:
                        raise ValueError('Training batch mode %s not supported' % self.mode)

                    actual_negative_samples_virtual = negative_sample_candidates_virtual[mask]
                    negative_sample_list_virtual.append(actual_negative_samples_virtual)
                    current_negative_sample_size += actual_negative_samples_virtual.size
                    # For only_true_negative, false_neg_mask is not really used or is all False
                    final_false_neg_mask_parts.append(np.zeros(actual_negative_samples_virtual.shape, dtype=bool))


            else:  # not only_true_negative, so we need to calculate false_neg_mask
                negative_sample_virtual = np.random.randint(self.nentity, size=self.negative_sample_size)
                if self.mode == 'head-batch':
                    true_entities_virtual = self.true_head.get((relation_orig_real, v_tail), np.array([]))
                    current_false_neg_mask = np.in1d(
                        negative_sample_virtual,
                        true_entities_virtual,  # VIRTUAL IDs
                        assume_unique=True,
                    )
                elif self.mode == 'tail-batch':
                    true_entities_virtual = self.true_tail.get((v_head, relation_orig_real), np.array([]))
                    current_false_neg_mask = np.in1d(
                        negative_sample_virtual,
                        true_entities_virtual,  # VIRTUAL IDs
                        assume_unique=True,
                    )
                else:
                    raise ValueError('Training batch mode %s not supported' % self.mode)
                negative_sample_list_virtual.append(negative_sample_virtual)
                final_false_neg_mask_parts.append(current_false_neg_mask)


        elif self.opts.sampling_method == 'gaussian':
            # `negative_sample_virtual` from normal distribution are VIRTUAL IDs
            if self.opts.only_true_negative:
                # false_neg_mask is implicitly all zeros
                while current_negative_sample_size < self.negative_sample_size:
                    if self.mode == 'head-batch':
                        negative_sample_candidates_virtual = np.random.normal(0.0, 1.0,
                                                                              self.opts.negative_sample_size * 2) * self.opts.variance + v_head  # factor 2 for oversampling
                        negative_sample_candidates_virtual = (negative_sample_candidates_virtual.astype(
                            np.int64) + self.nentity) % self.nentity
                        true_entities_virtual = self.true_head.get((relation_orig_real, v_tail), np.array([]))
                        mask = np.in1d(
                            negative_sample_candidates_virtual,
                            true_entities_virtual,  # VIRTUAL IDs
                            assume_unique=True,
                            invert=True
                        )
                    elif self.mode == 'tail-batch':
                        negative_sample_candidates_virtual = np.random.normal(0.0, 1.0,
                                                                              self.opts.negative_sample_size * 2) * self.opts.variance + v_tail
                        negative_sample_candidates_virtual = (negative_sample_candidates_virtual.astype(
                            np.int64) + self.nentity) % self.nentity
                        true_entities_virtual = self.true_tail.get((v_head, relation_orig_real), np.array([]))
                        mask = np.in1d(
                            negative_sample_candidates_virtual,
                            true_entities_virtual,  # VIRTUAL IDs
                            assume_unique=True,
                            invert=True
                        )
                    else:
                        raise ValueError('Training batch mode %s not supported' % self.mode)

                    actual_negative_samples_virtual = negative_sample_candidates_virtual[mask]
                    negative_sample_list_virtual.append(actual_negative_samples_virtual)
                    current_negative_sample_size += actual_negative_samples_virtual.size
                    final_false_neg_mask_parts.append(np.zeros(actual_negative_samples_virtual.shape, dtype=bool))

            else:  # not only_true_negative
                if self.mode == 'head-batch':
                    negative_sample_virtual = np.random.normal(0.0, 1.0,
                                                               self.opts.negative_sample_size) * self.opts.variance + v_head
                    negative_sample_virtual = (negative_sample_virtual.astype(np.int64) + self.nentity) % self.nentity
                    true_entities_virtual = self.true_head.get((relation_orig_real, v_tail), np.array([]))
                    current_false_neg_mask = np.in1d(
                        negative_sample_virtual,
                        true_entities_virtual,  # VIRTUAL IDs
                        assume_unique=True
                    )
                elif self.mode == 'tail-batch':
                    negative_sample_virtual = np.random.normal(0.0, 1.0,
                                                               self.opts.negative_sample_size) * self.opts.variance + v_tail
                    negative_sample_virtual = (negative_sample_virtual.astype(np.int64) + self.nentity) % self.nentity
                    true_entities_virtual = self.true_tail.get((v_head, relation_orig_real), np.array([]))
                    current_false_neg_mask = np.in1d(
                        negative_sample_virtual,
                        true_entities_virtual,  # VIRTUAL IDs
                        assume_unique=True
                    )
                else:
                    raise ValueError('Training batch mode %s not supported' % self.mode)
                negative_sample_list_virtual.append(negative_sample_virtual)
                final_false_neg_mask_parts.append(current_false_neg_mask)

        else:
            raise ValueError('Sampling method %s not supported' % self.opts.sampling_method)

        # Concatenate and slice to final size
        concatenated_negative_samples_virtual = np.concatenate(negative_sample_list_virtual)[:self.negative_sample_size]

        # Handle false_neg_mask for the final concatenated list
        if self.opts.only_true_negative:
            # If only_true_negative, the mask indicates no false negatives (all zeros/False)
            final_false_neg_mask = np.zeros(concatenated_negative_samples_virtual.shape, dtype=bool)
        else:
            # Concatenate the masks generated during sampling
            final_false_neg_mask = np.concatenate(final_false_neg_mask_parts)[:self.negative_sample_size]

        # Convert final virtual negative samples to real IDs for the model
        negative_sample_real_ids = [self.entity_proxy.get_real_id(vid) for vid in concatenated_negative_samples_virtual]

        output_positive_sample = torch.LongTensor(positive_sample_real)
        output_negative_sample = torch.LongTensor(negative_sample_real_ids)
        output_false_neg_mask = torch.FloatTensor(final_false_neg_mask)  # Ensure this is correctly sized

        return output_positive_sample, output_negative_sample, output_false_neg_mask, subsampling_weight, self.mode


    @staticmethod
    def collate_fn(data):
        positive_sample = torch.stack([_[0] for _ in data], dim=0)
        negative_sample = torch.stack([_[1] for _ in data], dim=0)
        false_neg_mask = torch.stack([_[2] for _ in data], dim=0)
        subsample_weight = torch.cat([_[3] for _ in data], dim=0)
        mode = data[0][4]
        return positive_sample, negative_sample, false_neg_mask, subsample_weight, mode

    @staticmethod
    def count_frequency(triples, start=4):
        count = {}
        for head, relation, tail in triples:  # These are REAL IDs
            if (head, relation) not in count:
                count[(head, relation)] = start
            else:
                count[(head, relation)] += 1
            if (tail, -relation - 1) not in count:
                count[(tail, -relation - 1)] = start
            else:
                count[(tail, -relation - 1)] += 1
        return count

    @staticmethod
    def get_true_head_and_tail(triples):  # Triples are REAL IDs
        true_head = {}  # key: (real_r, real_t), value: list of real_h
        true_tail = {}  # key: (real_h, real_r), value: list of real_t
        for head, relation, tail in triples:
            if (head, relation) not in true_tail:
                true_tail[(head, relation)] = []
            true_tail[(head, relation)].append(tail)
            if (relation, tail) not in true_head:
                true_head[(relation, tail)] = []
            true_head[(relation, tail)].append(head)
        for relation, tail in true_head:
            true_head[(relation, tail)] = np.array(list(set(true_head[(relation, tail)])))
        for head, relation in true_tail:
            true_tail[(head, relation)] = np.array(list(set(true_tail[(head, relation)])))
        return true_head, true_tail

    def update_curriculum(self, num_samples_to_use):
        if num_samples_to_use > len(self.all_sorted_triples):
            num_samples_to_use = len(self.all_sorted_triples)
        if num_samples_to_use < 0:
            num_samples_to_use = 0

        self.triples = self.all_sorted_triples[:num_samples_to_use]  # REAL ID triples
        self.len = len(self.triples)
        self.triple_set = set(self.triples)

        _real_count = TrainDataset.count_frequency(self.triples)
        _real_true_head, _real_true_tail = TrainDataset.get_true_head_and_tail(self.triples)

        self.count = {}
        for (e1_real, r_real_or_neg_rel), val in _real_count.items():
            v_e1 = self.entity_proxy.get_virtual_id(e1_real)
            self.count[(v_e1, r_real_or_neg_rel)] = val  # Key: (v_e1, relation)

        self.true_head = {}  # Key: (real_r, v_t), Value: [v_h1, v_h2,...]
        for (r_real, t_real), h_real_list in _real_true_head.items():
            v_t = self.entity_proxy.get_virtual_id(t_real)
            self.true_head[(r_real, v_t)] = np.array([self.entity_proxy.get_virtual_id(h_r) for h_r in h_real_list])

        self.true_tail = {}  # Key: (v_h, real_r), Value: [v_t1, v_t2,...]
        for (h_real, r_real), t_real_list in _real_true_tail.items():
            v_h = self.entity_proxy.get_virtual_id(h_real)
            self.true_tail[(v_h, r_real)] = np.array([self.entity_proxy.get_virtual_id(t_r) for t_r in t_real_list])

    def update_proxy(self, old_virtual_to_new_virtual_map):
        """
        This method is called when the entity ID mapping (virtual IDs) changes,
        e.g., after reorder_embeddings.
        It first updates the internal entity_proxy.
        Then, it MUST rebuild self.count, self.true_head, self.true_tail based on
        self.triples (which are REAL IDs) using the NEW proxy mapping.
        """
        self.entity_proxy.update(old_virtual_to_new_virtual_map)  # Updates virtual<->real map

        # Now, rebuild internal structures using the NEW self.entity_proxy state
        # and the current self.triples (which are still real IDs)
        # This is the same logic as in update_curriculum's latter half or __init__'s latter half
        _real_count = TrainDataset.count_frequency(self.triples)
        _real_true_head, _real_true_tail = TrainDataset.get_true_head_and_tail(self.triples)

        self.count = {}
        for (e1_real, r_real_or_neg_rel), val in _real_count.items():
            v_e1 = self.entity_proxy.get_virtual_id(e1_real)  # Uses NEW proxy
            self.count[(v_e1, r_real_or_neg_rel)] = val

        self.true_head = {}
        for (r_real, t_real), h_real_list in _real_true_head.items():
            v_t = self.entity_proxy.get_virtual_id(t_real)  # Uses NEW proxy
            self.true_head[(r_real, v_t)] = np.array([self.entity_proxy.get_virtual_id(h_r) for h_r in h_real_list])

        self.true_tail = {}
        for (h_real, r_real), t_real_list in _real_true_tail.items():
            v_h = self.entity_proxy.get_virtual_id(h_real)  # Uses NEW proxy
            self.true_tail[(v_h, r_real)] = np.array([self.entity_proxy.get_virtual_id(t_r) for t_r in t_real_list])


class TestDataset(Dataset):
    def __init__(self, triples, all_true_triples, nentity, nrelation, mode):
        self.len = len(triples)
        self.triple_set = set(all_true_triples)
        self.triples = triples
        self.nentity = nentity
        self.nrelation = nrelation
        self.mode = mode

    def __len__(self):
        return self.len

    def __getitem__(self, idx):
        head, relation, tail = self.triples[idx]

        if self.mode == 'head-batch':
            tmp = [(0, rand_head) if (rand_head, relation, tail) not in self.triple_set
                   else (-1, head) for rand_head in range(self.nentity)]
            tmp[head] = (0, head)
        elif self.mode == 'tail-batch':
            tmp = [(0, rand_tail) if (head, relation, rand_tail) not in self.triple_set
                   else (-1, tail) for rand_tail in range(self.nentity)]
            tmp[tail] = (0, tail)
        else:
            raise ValueError('negative batch mode %s not supported' % self.mode)

        tmp = torch.LongTensor(tmp)
        filter_bias = tmp[:, 0].float()
        negative_sample = tmp[:, 1]

        positive_sample = torch.LongTensor((head, relation, tail))

        return positive_sample, negative_sample, filter_bias, self.mode

    @staticmethod
    def collate_fn(data):
        positive_sample = torch.stack([_[0] for _ in data], dim=0)
        negative_sample = torch.stack([_[1] for _ in data], dim=0)
        filter_bias = torch.stack([_[2] for _ in data], dim=0)
        mode = data[0][3]
        return positive_sample, negative_sample, filter_bias, mode


class BidirectionalOneShotIterator(object):
    def __init__(self, dataloader_head, dataloader_tail):
        self.iterator_head = self.one_shot_iterator(dataloader_head)
        self.iterator_tail = self.one_shot_iterator(dataloader_tail)
        self.step = 0

    def __next__(self):
        self.step += 1
        if self.step % 2 == 0:
            data = next(self.iterator_head)
        else:
            data = next(self.iterator_tail)
        return data

    @staticmethod
    def one_shot_iterator(dataloader):
        '''
        Transform a PyTorch Dataloader into python iterator
        '''
        while True:
            for data in dataloader:
                yield data

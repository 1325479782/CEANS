#!/usr/bin/python3

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch
import torch.nn as nn
import torch.nn.functional as F

from .kge_model import KGEModel


class HousE_r_plus(KGEModel):
    def __init__(self, model_name, nentity, nrelation, hidden_dim, gamma, house_dim, house_num,
                 double_entity_embedding=False, double_relation_embedding=False, **kwargs):

        feature_dim_per_house = int(hidden_dim / house_dim)

        super(HousE_r_plus, self).__init__(
            model_name=model_name,
            nentity=nentity,
            nrelation=nrelation,
            hidden_dim=feature_dim_per_house,
            gamma=gamma,
            double_entity_embedding=double_entity_embedding,
            double_relation_embedding=double_relation_embedding
        )

        self.actual_model_name = model_name
        self.hidden_dim_per_house = feature_dim_per_house
        self.house_dim = house_dim
        self.house_num = house_num

        self.epsilon = 2.0
        self.embedding_range = nn.Parameter(
            torch.Tensor([(self.gamma.item() + self.epsilon) / (self.hidden_dim_per_house * (self.house_dim ** 0.5))]),
            requires_grad=False
        )

        self.entity_embedding = nn.Parameter(torch.zeros(self.nentity, self.hidden_dim_per_house, self.house_dim))
        nn.init.uniform_(tensor=self.entity_embedding, a=-self.embedding_range.item(), b=self.embedding_range.item())

        self.relation_embedding = nn.Parameter(
            torch.zeros(self.nrelation, self.hidden_dim_per_house, self.house_dim * self.house_num))
        nn.init.uniform_(tensor=self.relation_embedding, a=-self.embedding_range.item(), b=self.embedding_range.item())

        self.relation_weight = nn.Parameter(torch.zeros(self.nrelation, self.hidden_dim_per_house, self.house_dim))
        nn.init.uniform_(tensor=self.relation_weight, a=-self.embedding_range.item(), b=self.embedding_range.item())

    def norm_relation_embeddings(self):
        r_list = torch.chunk(self.relation_embedding, self.house_num, 2)
        normed_r_list = [F.normalize(r_i, p=2, dim=2) for r_i in r_list]
        return torch.cat(normed_r_list, dim=2)

    def get_sample_embeddings(self, sample, mode):
        normed_relation_embed = self.norm_relation_embeddings()

        re_weight_selected = None

        if mode == 'single':
            head_indices = sample[:, 0]
            relation_indices = sample[:, 1]
            tail_indices = sample[:, 2]

            head = torch.index_select(self.entity_embedding, dim=0, index=head_indices).unsqueeze(1)
            relation = torch.index_select(normed_relation_embed, dim=0, index=relation_indices).unsqueeze(1)
            tail = torch.index_select(self.entity_embedding, dim=0, index=tail_indices).unsqueeze(1)
            re_weight_selected = torch.index_select(self.relation_weight, dim=0, index=relation_indices).unsqueeze(1)

        elif mode == 'head-batch':
            tail_part, head_part = sample
            batch_size, negative_sample_size = head_part.size(0), head_part.size(1)
            head_indices = head_part.view(-1)
            relation_indices = tail_part[:, 1]
            tail_indices = tail_part[:, 2]

            head = torch.index_select(self.entity_embedding, dim=0, index=head_indices).view(batch_size,
                                                                                             negative_sample_size,
                                                                                             self.hidden_dim_per_house,
                                                                                             self.house_dim)
            relation = torch.index_select(normed_relation_embed, dim=0, index=relation_indices).unsqueeze(1)
            tail = torch.index_select(self.entity_embedding, dim=0, index=tail_indices).unsqueeze(1)
            re_weight_selected = torch.index_select(self.relation_weight, dim=0, index=relation_indices).unsqueeze(1)

        elif mode == 'tail-batch':
            head_part, tail_part = sample
            batch_size, negative_sample_size = tail_part.size(0), tail_part.size(1)
            head_indices = head_part[:, 0]
            relation_indices = head_part[:, 1]
            tail_indices = tail_part.view(-1)

            head = torch.index_select(self.entity_embedding, dim=0, index=head_indices).unsqueeze(1)
            relation = torch.index_select(normed_relation_embed, dim=0, index=relation_indices).unsqueeze(1)
            tail = torch.index_select(self.entity_embedding, dim=0, index=tail_indices).view(batch_size,
                                                                                             negative_sample_size,
                                                                                             self.hidden_dim_per_house,
                                                                                             self.house_dim)
            re_weight_selected = torch.index_select(self.relation_weight, dim=0, index=relation_indices).unsqueeze(1)
        else:
            raise ValueError('mode %s not supported' % mode)

        relation_bundle = (relation, re_weight_selected, None, None)  # (base_r, re_weight, k_head, k_tail)
        return head, relation_bundle, tail

    def scoring(self, head, relation_bundle, tail, mode):
        relation, re_weight, _, _ = relation_bundle

        r_list = torch.chunk(relation, self.house_num, 3)

        if mode == 'head-batch':
            for i in range(self.house_num):
                tail = tail - 2 * torch.sum(r_list[i] * tail, dim=-1, keepdim=True) * r_list[i]
            tail = tail - re_weight  # Apply translation after reflections
            cos_score = tail - head
        else:  # 'tail-batch' or 'single'
            head = head + re_weight  # Apply translation before reflections
            for i in range(self.house_num):
                j = self.house_num - 1 - i
                head = head - 2 * torch.sum(r_list[j] * head, dim=-1, keepdim=True) * r_list[j]
            cos_score = head - tail

        distance = torch.sum(cos_score.norm(p=2, dim=3), dim=2)
        score = self.gamma.item() - distance
        return score
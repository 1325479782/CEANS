#!/usr/bin/python3

import torch
import torch.nn.functional as F

# Assuming the KGEModel class (from the second file you provided)
# is in a file named 'kge_model_scaffold.py' in the same directory or a resolvable path.
# Adjust the import path as necessary.
from .kge_model import KGEModel


class PairRE(KGEModel):
    def __init__(self, model_name, nentity, nrelation, hidden_dim, gamma,
                 double_entity_embedding, double_relation_embedding):
        super(PairRE, self).__init__(model_name, nentity, nrelation, hidden_dim, gamma,
                                     double_entity_embedding, double_relation_embedding)

    def scoring(self, head, relation, tail, mode):
        re_head, re_tail = torch.chunk(relation, 2, dim=2)

        head = F.normalize(head, 2, -1)
        tail = F.normalize(tail, 2, -1)

        score = head * re_head - tail * re_tail
        score = self.gamma.item() - torch.norm(score, p=1, dim=2)
        return score
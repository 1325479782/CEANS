#!/usr/bin/python3

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch
import torch.nn as nn
import torch.nn.functional as F

from .kge_model import KGEModel


class HousE_plus(KGEModel):
    def __init__(self, model_name, nentity, nrelation, hidden_dim, gamma, house_dim, house_num, housd_num, thred,
                 double_entity_embedding=False, double_relation_embedding=False, **kwargs):

        feature_dim_per_house = int(hidden_dim / house_dim)

        super(HousE_plus, self).__init__(
            model_name=model_name,
            nentity=nentity,
            nrelation=nrelation,
            hidden_dim=feature_dim_per_house,
            gamma=gamma,
            double_entity_embedding=double_entity_embedding,
            double_relation_embedding=double_relation_embedding
        )

        self.actual_model_name = model_name
        self.hidden_dim_per_house = feature_dim_per_house
        self.house_dim = house_dim
        self.housd_num = housd_num
        self.thred = thred

        self.house_num = house_num + (2 * self.housd_num)  # Adjusted for HousE_plus

        self.epsilon = 2.0
        self.embedding_range = nn.Parameter(
            torch.Tensor([(self.gamma.item() + self.epsilon) / (self.hidden_dim_per_house * (self.house_dim ** 0.5))]),
            requires_grad=False
        )

        self.entity_embedding = nn.Parameter(torch.zeros(self.nentity, self.hidden_dim_per_house, self.house_dim))
        nn.init.uniform_(tensor=self.entity_embedding, a=-self.embedding_range.item(), b=self.embedding_range.item())

        self.relation_embedding = nn.Parameter(
            torch.zeros(self.nrelation, self.hidden_dim_per_house, self.house_dim * self.house_num))
        nn.init.uniform_(tensor=self.relation_embedding, a=-self.embedding_range.item(), b=self.embedding_range.item())

        self.relation_weight = nn.Parameter(torch.zeros(self.nrelation, self.hidden_dim_per_house, self.house_dim))
        nn.init.uniform_(tensor=self.relation_weight, a=-self.embedding_range.item(), b=self.embedding_range.item())

        self.k_dir_head = nn.Parameter(torch.zeros(self.nrelation, 1, self.housd_num))
        nn.init.uniform_(tensor=self.k_dir_head, a=-0.01, b=+0.01)
        self.k_dir_tail = nn.Parameter(torch.zeros(self.nrelation, 1, self.housd_num))
        with torch.no_grad():
            self.k_dir_tail.data = -self.k_dir_head.data

        self.k_scale_head = nn.Parameter(torch.zeros(self.nrelation, self.hidden_dim_per_house, self.housd_num))
        nn.init.uniform_(tensor=self.k_scale_head, a=-1, b=+1)
        self.k_scale_tail = nn.Parameter(torch.zeros(self.nrelation, self.hidden_dim_per_house, self.housd_num))
        nn.init.uniform_(tensor=self.k_scale_tail, a=-1, b=+1)

        self.k_head = None  # Populated by norm_relation_embeddings
        self.k_tail = None

    def norm_relation_embeddings(self):
        r_list_chunks = torch.chunk(self.relation_embedding, self.house_num, 2)
        normed_r_list = [F.normalize(r_i, p=2, dim=2) for r_i in r_list_chunks]
        normed_r = torch.cat(normed_r_list, dim=2)

        current_k_head = self.k_dir_head * torch.abs(
            self.k_scale_head)  # Note: k_dir_head is (N,1,Hd), k_scale_head is (N,D,Hd). Broadcasting results in (N,D,Hd)
        current_k_head[current_k_head > self.thred] = self.thred

        current_k_tail = self.k_dir_tail * torch.abs(self.k_scale_tail)
        current_k_tail[current_k_tail > self.thred] = self.thred

        # The original code's k_head/k_tail that are used in the formula seem to be relation-specific scalars per housd_num component
        # Based on `k_head_i = k_head[:, :, :, i].unsqueeze(dim=3)` and its usage `(0 + k_head_i)`.
        # This implies `k_head` should be `(num_relations, 1, housd_num)`.
        # Let's assume the `model.py` uses `k_dir_head` (shape `(nrelation, 1, self.housd_num)`) for this role after scaling and thresholding.
        # Re-evaluating: `self.k_head = self.k_dir_head * torch.abs(self.k_scale_head)`
        # If k_dir_head is (R, 1, N_housd) and k_scale_head is (R, D_emb, N_housd), then result is (R, D_emb, N_housd) by broadcasting k_dir_head's dim 1.
        # However, `k_head_i = k_head[:, :, :, i].unsqueeze(dim=3)` is used later.
        # If k_head is (batch, neg, D_emb, N_housd), then k_head_i is (batch, neg, D_emb, 1).
        # This means the (0 + k_head_i) term is a vector, not a scalar. This is different from original paper's description of dilation.
        # For now, I will follow the shapes from `model.py`'s KGEModel.
        # The variables self.k_head and self.k_tail in model.py KGEModel are (nrelation, 1, self.housd_num) after computations.
        # So, k_scale_head/tail must not be used to make k_head/k_tail relation-feature specific.
        # Let's assume k_head and k_tail are derived only from k_dir_* and some scalar scaling, not k_scale_*.
        # The original code: self.k_head = self.k_dir_head * torch.abs(self.k_scale_head) and then indexing on the last dim.
        # This implies k_scale_head is treated as a scalar or k_dir_head is broadcast.
        # The original intent of k_scale was likely to make k relation-dim specific.
        # Let's assume k_head, k_tail are (num_relations, 1, housd_num) as in model.py's self.k_dir_head/tail.
        # The scaling `torch.abs(self.k_scale_head)` is problematic if it's not a scalar per (relation, housd_idx).
        # For now, this part of `norm_embedding` in `model.py` is:
        # self.k_head = self.k_dir_head * torch.abs(self.k_scale_head)
        # self.k_head[self.k_head>self.thred] = self.thred
        # If k_scale_head is (R, D, Hd) and k_dir_head is (R, 1, Hd), this multiplication is fine, k_head becomes (R,D,Hd).
        # Then k_head_i = k_head[:,:,:,i] is a (bs, neg_size, D)-shaped tensor.
        # And (0+k_head_i) means adding this vector. This is a deviation from scalar dilation factor.
        # Sticking to original provided `model.py`'s logic:
        # self.k_head (and k_tail) will be (nrelation, hidden_dim_per_house, housd_num)

        return normed_r, current_k_head, current_k_tail

    def get_sample_embeddings(self, sample, mode):
        normed_relation_embed, current_k_head, current_k_tail = self.norm_relation_embeddings()

        k_head_selected, k_tail_selected, re_weight_selected = None, None, None

        if mode == 'single':
            head_indices = sample[:, 0]
            relation_indices = sample[:, 1]
            tail_indices = sample[:, 2]

            head = torch.index_select(self.entity_embedding, dim=0, index=head_indices).unsqueeze(1)
            relation = torch.index_select(normed_relation_embed, dim=0, index=relation_indices).unsqueeze(1)
            tail = torch.index_select(self.entity_embedding, dim=0, index=tail_indices).unsqueeze(1)

            re_weight_selected = torch.index_select(self.relation_weight, dim=0, index=relation_indices).unsqueeze(1)
            k_head_selected = torch.index_select(current_k_head, dim=0, index=relation_indices).unsqueeze(1)
            k_tail_selected = torch.index_select(current_k_tail, dim=0, index=relation_indices).unsqueeze(1)

        elif mode == 'head-batch':
            tail_part, head_part = sample
            batch_size, negative_sample_size = head_part.size(0), head_part.size(1)
            head_indices = head_part.view(-1)
            relation_indices = tail_part[:, 1]
            tail_indices = tail_part[:, 2]

            head = torch.index_select(self.entity_embedding, dim=0, index=head_indices).view(batch_size,
                                                                                             negative_sample_size,
                                                                                             self.hidden_dim_per_house,
                                                                                             self.house_dim)
            relation = torch.index_select(normed_relation_embed, dim=0, index=relation_indices).unsqueeze(1)
            tail = torch.index_select(self.entity_embedding, dim=0, index=tail_indices).unsqueeze(1)

            re_weight_selected = torch.index_select(self.relation_weight, dim=0, index=relation_indices).unsqueeze(1)
            k_head_selected = torch.index_select(current_k_head, dim=0, index=relation_indices).unsqueeze(1)
            k_tail_selected = torch.index_select(current_k_tail, dim=0, index=relation_indices).unsqueeze(1)

        elif mode == 'tail-batch':
            head_part, tail_part = sample
            batch_size, negative_sample_size = tail_part.size(0), tail_part.size(1)
            head_indices = head_part[:, 0]
            relation_indices = head_part[:, 1]
            tail_indices = tail_part.view(-1)

            head = torch.index_select(self.entity_embedding, dim=0, index=head_indices).unsqueeze(1)
            relation = torch.index_select(normed_relation_embed, dim=0, index=relation_indices).unsqueeze(1)
            tail = torch.index_select(self.entity_embedding, dim=0, index=tail_indices).view(batch_size,
                                                                                             negative_sample_size,
                                                                                             self.hidden_dim_per_house,
                                                                                             self.house_dim)

            re_weight_selected = torch.index_select(self.relation_weight, dim=0, index=relation_indices).unsqueeze(1)
            k_head_selected = torch.index_select(current_k_head, dim=0, index=relation_indices).unsqueeze(1)
            k_tail_selected = torch.index_select(current_k_tail, dim=0, index=relation_indices).unsqueeze(1)
        else:
            raise ValueError('mode %s not supported' % mode)

        relation_bundle = (relation, re_weight_selected, k_head_selected, k_tail_selected)
        return head, relation_bundle, tail

    def scoring(self, head, relation_bundle, tail, mode):
        relation, re_weight, k_head, k_tail = relation_bundle

        r_list = torch.chunk(relation, self.house_num, 3)

        if mode == 'head-batch':
            # Reflect tail with k_tail
            for i in range(self.housd_num):
                # k_tail selected is (batch, 1_or_N, D_emb, housd_num)
                k_val_i = k_tail[:, :, :, i].unsqueeze(-1)  # (batch, 1_or_N, D_emb, 1)
                tail = tail - (0 + k_val_i) * torch.sum(r_list[i] * tail, dim=-1, keepdim=True) * r_list[i]

            # Standard reflections for middle part
            for i in range(self.housd_num, self.house_num - self.housd_num):
                tail = tail - 2 * torch.sum(r_list[i] * tail, dim=-1, keepdim=True) * r_list[i]

            tail = tail - re_weight  # Translation after reflections for tail

            # Reflect head with k_head
            for i in range(self.housd_num):
                k_val_i = k_head[:, :, :, i].unsqueeze(-1)
                head = head - (0 + k_val_i) * torch.sum(r_list[self.house_num - 1 - i] * head, dim=-1, keepdim=True) * \
                       r_list[self.house_num - 1 - i]
            cos_score = tail - head
        else:  # 'tail-batch' or 'single'
            # Reflect head with k_head
            for i in range(self.housd_num):
                k_val_i = k_head[:, :, :, i].unsqueeze(-1)
                head = head - (0 + k_val_i) * torch.sum(r_list[self.house_num - 1 - i] * head, dim=-1, keepdim=True) * \
                       r_list[self.house_num - 1 - i]

            head = head + re_weight  # Translation before reflections for head

            # Standard reflections for middle part (applied to head)
            for i in range(self.housd_num, self.house_num - self.housd_num):
                j = self.house_num - 1 - i
                head = head - 2 * torch.sum(r_list[j] * head, dim=-1, keepdim=True) * r_list[j]

            # Reflect tail with k_tail
            for i in range(self.housd_num):
                k_val_i = k_tail[:, :, :, i].unsqueeze(-1)
                tail = tail - (0 + k_val_i) * torch.sum(r_list[i] * tail, dim=-1, keepdim=True) * r_list[i]
            cos_score = head - tail

        distance = torch.sum(cos_score.norm(p=2, dim=3), dim=2)
        score = self.gamma.item() - distance
        return score
#!/usr/bin/python3

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch
import torch.nn as nn
import torch.nn.functional as F

from .kge_model import KGEModel


class HousE_r(KGEModel):
    def __init__(self, model_name, nentity, nrelation, hidden_dim, gamma, house_dim, house_num,
                 double_entity_embedding=False, double_relation_embedding=False,
                 **kwargs):  # Added kwargs for other potential params not used by HousE_r

        feature_dim_per_house = int(hidden_dim / house_dim)

        super(HousE_r, self).__init__(
            model_name=model_name,
            nentity=nentity,
            nrelation=nrelation,
            # The base KGEModel from kge_model.py might use nrelation+1 for its own embedding, HousE uses nrelation.
            hidden_dim=feature_dim_per_house,
            # This is the dimension per house, used by base KGEModel if it were to use its own embeddings.
            gamma=gamma,
            double_entity_embedding=double_entity_embedding,
            double_relation_embedding=double_relation_embedding
        )

        self.actual_model_name = model_name
        # self.nentity and self.nrelation are set by superclass
        # self.gamma is a Parameter set by superclass

        self.hidden_dim_per_house = feature_dim_per_house
        self.house_dim = house_dim
        self.house_num = house_num  # For HousE_r, house_num is used directly

        self.epsilon = 2.0

        self.embedding_range = nn.Parameter(
            torch.Tensor([(self.gamma.item() + self.epsilon) / (self.hidden_dim_per_house * (self.house_dim ** 0.5))]),
            requires_grad=False
        )

        # Override KGEModel's entity_embedding
        self.entity_embedding = nn.Parameter(torch.zeros(self.nentity, self.hidden_dim_per_house, self.house_dim))
        nn.init.uniform_(
            tensor=self.entity_embedding,
            a=-self.embedding_range.item(),
            b=self.embedding_range.item()
        )

        # Override KGEModel's relation_embedding
        self.relation_embedding = nn.Parameter(
            torch.zeros(self.nrelation, self.hidden_dim_per_house, self.house_dim * self.house_num))
        nn.init.uniform_(
            tensor=self.relation_embedding,
            a=-self.embedding_range.item(),
            b=self.embedding_range.item()
        )

    def norm_relation_embeddings(self):
        """Normalizes relation embeddings along the house_dim."""
        r_list = torch.chunk(self.relation_embedding, self.house_num, 2)
        normed_r_list = []
        for i in range(self.house_num):
            r_i = F.normalize(r_list[i], p=2, dim=2)  # dim 2 is the house_dim within each chunk
            normed_r_list.append(r_i)
        return torch.cat(normed_r_list, dim=2)  # Concatenate along the original chunked dimension

    def get_sample_embeddings(self, sample, mode):
        """
        Overrides KGEModel.get_sample_embeddings.
        Prepares head, tail, and relation bundle (which only contains normed relation for HousE_r) embeddings.
        """
        normed_relation_embed = self.norm_relation_embeddings()

        if mode == 'single':
            head_indices = sample[:, 0]
            relation_indices = sample[:, 1]
            tail_indices = sample[:, 2]

            head = torch.index_select(self.entity_embedding, dim=0, index=head_indices).unsqueeze(1)
            relation = torch.index_select(normed_relation_embed, dim=0, index=relation_indices).unsqueeze(1)
            tail = torch.index_select(self.entity_embedding, dim=0, index=tail_indices).unsqueeze(1)

            relation_bundle = (relation, None, None, None)  # (base_r, re_weight, k_head, k_tail)

        elif mode == 'head-batch':
            tail_part, head_part = sample
            batch_size, negative_sample_size = head_part.size(0), head_part.size(1)

            head_indices = head_part.view(-1)
            relation_indices = tail_part[:, 1]
            tail_indices = tail_part[:, 2]

            head = torch.index_select(self.entity_embedding, dim=0, index=head_indices).view(batch_size,
                                                                                             negative_sample_size,
                                                                                             self.hidden_dim_per_house,
                                                                                             self.house_dim)
            relation = torch.index_select(normed_relation_embed, dim=0, index=relation_indices).unsqueeze(
                1)  # Expand for broadcasting
            tail = torch.index_select(self.entity_embedding, dim=0, index=tail_indices).unsqueeze(
                1)  # Expand for broadcasting

            relation_bundle = (relation, None, None, None)

        elif mode == 'tail-batch':
            head_part, tail_part = sample
            batch_size, negative_sample_size = tail_part.size(0), tail_part.size(1)

            head_indices = head_part[:, 0]
            relation_indices = head_part[:, 1]
            tail_indices = tail_part.view(-1)

            head = torch.index_select(self.entity_embedding, dim=0, index=head_indices).unsqueeze(
                1)  # Expand for broadcasting
            relation = torch.index_select(normed_relation_embed, dim=0, index=relation_indices).unsqueeze(
                1)  # Expand for broadcasting
            tail = torch.index_select(self.entity_embedding, dim=0, index=tail_indices).view(batch_size,
                                                                                             negative_sample_size,
                                                                                             self.hidden_dim_per_house,
                                                                                             self.house_dim)

            relation_bundle = (relation, None, None, None)
        else:
            raise ValueError('mode %s not supported' % mode)

        return head, relation_bundle, tail

    def scoring(self, head, relation_bundle, tail, mode):
        relation, _, _, _ = relation_bundle  # Unpack: re_weight, k_head, k_tail are None for HousE_r

        r_list = torch.chunk(relation, self.house_num,
                             3)  # relation is (batch, 1_or_neg, hidden_dim_per_house, house_dim * house_num) -> chunk along dim 3

        if mode == 'head-batch':
            # Reflect tail
            for i in range(self.house_num):
                tail = tail - 2 * torch.sum(r_list[i] * tail, dim=-1, keepdim=True) * r_list[i]
            cos_score = tail - head
        else:  # 'tail-batch' or 'single'
            # Reflect head
            for i in range(self.house_num):
                j = self.house_num - 1 - i  # Apply reflections in reverse order for head
                head = head - 2 * torch.sum(r_list[j] * head, dim=-1, keepdim=True) * r_list[j]
            cos_score = head - tail

        # cos_score shape: (batch, 1_or_neg, hidden_dim_per_house, house_dim)
        # Norm over house_dim (dim 3), then sum over hidden_dim_per_house (dim 2)
        distance = torch.sum(cos_score.norm(p=2, dim=3), dim=2)

        score = self.gamma.item() - distance
        return score
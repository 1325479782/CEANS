from .kge_model import KGEModel
from .transe import TransE
from .transd import TransD
from .rotate import RotatE
from .distmult import DistMult
from .complex import ComplEx
from .pairre import PairRE

#!/bin/sh

python -u -c 'import torch; print(torch.__version__)'

CODE_PATH=codes # Assuming your Python script is in 'codes/run.py'
DATA_PATH=data
SAVE_PATH=models

MODE=train
MODEL=TransE
DATASET=FB15k-237
GPU_DEVICE=0
SAVE_ID=15cl4 # An identifier for this specific run/configuration with CL

FULL_DATA_PATH=$DATA_PATH/$DATASET
SAVE=$SAVE_PATH/"$MODEL"_"$DATASET"_"$SAVE_ID"

# Best Configs / Training Parameters
BATCH_SIZE=1024
NEGATIVE_SAMPLE_SIZE=64
HIDDEN_DIM=1000
GAMMA=9.0
ALPHA=1.0 # Adversarial temperature
LEARNING_RATE=0.00005
REGULARIZATION=0.0
MAX_STEPS=100000
TEST_BATCH_SIZE=16 # Batch size for validation and testing
SAMPLING_METHOD=gaussian # Example: 'uniform' or 'gaussian'
NCLUSTERS=100 # For Gaussian sampling K-means
VARIANCE=290 # For Gaussian sampling variance
REORDER_STEPS=1000 # For Gaussian sampling reorder
SUB_LOSS_WEIGHT=1.0
SUB_REGULARIZATION=0.1

# Early Stopping Parameters
EARLY_STOPPING_PATIENCE=2
EARLY_STOPPING_METRIC="HITS@10"
VALID_STEPS=5000

# --- Curriculum Learning Parameters ---
CURRICULUM_LEARNING_ENABLED=true # Set to true to enable, or remove if default is false in python
CL_PACING_FUNCTION="geometric"   # 'linear', 'root', 'geometric'
#CL_START_PERCENTAGE=0.385        # Optional: explicitly set p0 (e.g., 0.1 for 10%). If commented out, calculated by script.
CL_T_GROW=8                     # Number of "periods" (defined by CL_UPDATE_STEPS) to reach 100% data
CL_UPDATE_STEPS=$VALID_STEPS     # Update curriculum every N steps (e.g., align with validation)
CL_MIN_Z_COUNT_FOR_HARD=1        # Z-count threshold for calculating p0 if CL_START_PERCENTAGE is not set

# Create save directory if it doesn't exist
mkdir -p $SAVE

# Construct curriculum learning arguments string
CL_ARGS=""
if [ "$CURRICULUM_LEARNING_ENABLED" = true ] ; then
    CL_ARGS="$CL_ARGS --curriculum_learning"
    CL_ARGS="$CL_ARGS --cl_pacing_function $CL_PACING_FUNCTION"
    if [ ! -z "$CL_START_PERCENTAGE" ]; then # Check if CL_START_PERCENTAGE is set and not empty
        CL_ARGS="$CL_ARGS --cl_start_percentage $CL_START_PERCENTAGE"
    fi
    CL_ARGS="$CL_ARGS --cl_T_grow $CL_T_GROW"
    CL_ARGS="$CL_ARGS --cl_update_steps $CL_UPDATE_STEPS"
    CL_ARGS="$CL_ARGS --cl_min_z_count_for_hard $CL_MIN_Z_COUNT_FOR_HARD"
    echo "Curriculum Learning Enabled with Pacing: $CL_PACING_FUNCTION, T_grow: $CL_T_GROW, Update Steps: $CL_UPDATE_STEPS"
fi


if [ $MODE == "train" ]
then

echo "Start Training......"
echo "Data Path: $FULL_DATA_PATH"
echo "Save Path: $SAVE"
echo "Model: $MODEL"
echo "Max Steps: $MAX_STEPS"
echo "Early Stopping Patience: $EARLY_STOPPING_PATIENCE (Metric: $EARLY_STOPPING_METRIC, Freq: $VALID_STEPS steps)"

CUDA_VISIBLE_DEVICES=$GPU_DEVICE python -u $CODE_PATH/run1.py --do_train \
    --cuda \
    --do_valid \
    --do_test \
    --data_path $FULL_DATA_PATH \
    --model $MODEL \
    -n $NEGATIVE_SAMPLE_SIZE -b $BATCH_SIZE -d $HIDDEN_DIM \
    -g $GAMMA -a $ALPHA -r $REGULARIZATION \
    -lr $LEARNING_RATE --max_steps $MAX_STEPS \
    -save $SAVE --test_batch_size $TEST_BATCH_SIZE \
    --valid_steps $VALID_STEPS \
    -sm $SAMPLING_METHOD \
    -k $NCLUSTERS  -v $VARIANCE --reorder_steps $REORDER_STEPS \
    -sub --sub_loss_weight $SUB_LOSS_WEIGHT --sub_regularization $SUB_REGULARIZATION \
    -adv \
    --early_stopping_patience $EARLY_STOPPING_PATIENCE \
    --early_stopping_metric $EARLY_STOPPING_METRIC \
    $CL_ARGS # Add curriculum learning arguments here

elif [ $MODE == "valid" ]
then

echo "Start Evaluation on Valid Data Set......"
echo "Loading model from: $SAVE"

CUDA_VISIBLE_DEVICES=$GPU_DEVICE python -u $CODE_PATH/run1.py --do_valid --cuda -init $SAVE \
    --test_batch_size $TEST_BATCH_SIZE
    # Curriculum learning parameters are not typically needed for validation/testing
    # as they affect training data presentation.

elif [ $MODE == "test" ]
then

echo "Start Evaluation on Test Data Set......"
echo "Loading model from: $SAVE"

CUDA_VISIBLE_DEVICES=$GPU_DEVICE python -u $CODE_PATH/run1.py --do_test --cuda -init $SAVE \
    --test_batch_size $TEST_BATCH_SIZE
    # Curriculum learning parameters are not typically needed for validation/testing.

else
   echo "Unknown MODE" $MODE
fi